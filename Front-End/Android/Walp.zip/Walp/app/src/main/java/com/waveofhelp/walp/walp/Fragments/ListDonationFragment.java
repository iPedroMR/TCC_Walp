package com.waveofhelp.walp.walp.Fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.waveofhelp.walp.walp.Activity.CreateEditNeedActivity;
import com.waveofhelp.walp.walp.Adapters.RVNEAdapter;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.Objects.Needs;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListDonationFragment extends Fragment {

    private static final int MY_PERMISSION_REQUEST_CODE = 0;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 0;
    private List<Needs> needsList;
    protected SwipeRefreshLayout mSwipeRefreshLayout;
    RVNEAdapter adapter;
    RequestQueue queue;

    private ProgressBar progressBar;
    public LinearLayout connectionViewFailed;
    public RecyclerView rv;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    public ListDonationFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_list_donation, container, false);

        rv = rootView.findViewById(R.id.rv);

        progressBar = rootView.findViewById(R.id.progressBar);

        connectionViewFailed = rootView.findViewById(R.id.connection_failed);

        FloatingActionButton floatingActionButtonAdd = rootView.findViewById(R.id.floating_add_button);

        connectionViewFailed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkInternet()){
                    getData();
                }else{
                    Toast.makeText(getContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                }
            }
        });

        floatingActionButtonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), CreateEditNeedActivity.class);
                startActivity(intent);
            }
        });

        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        //Initializing our list
        needsList = new ArrayList<>();
        queue = Volley.newRequestQueue(getContext());

        //initializing our adapter
        adapter = new RVNEAdapter(needsList, getContext());

        //Adding adapter to recyclerview
        rv.setAdapter(adapter);

        //SWIPE LAYOUT
        mSwipeRefreshLayout = rootView.findViewById(R.id.srl_swipe);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                //AÇÃO SWIPE REFRESH LAYOUT
                if(checkInternet()) {
                    getData();
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        return rootView;
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getContext());
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode,
                        getActivity(), PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Toast.makeText(getContext(), "This device is not supported", Toast.LENGTH_LONG).show();
            }
            return false;
        }
        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        getData();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (checkPlayServices())
                        getData();
                }
                break;
        }
    }
    private JsonArrayRequest getDataFromServer(int requestCount){

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getContext()).getRequestQueue();

        String id;

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        //Volley's inbuilt class to make Json array request
        String url = Constants.URL_FEED_NEED;
        return new JsonArrayRequest (url+"?id_ong="+id, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {

                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        });
    }

    //This method will get data from the web api
    private void getData() {
        needsList.clear();
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {

            progressBar.setVisibility(View.GONE);
            //Creating the superhero object
            Needs needs = new Needs();
            JSONObject json;
            try {
                //Getting json
                json = array.getJSONObject(i);

                //Adding data to the ONG object
                needs.setName(json.getString("NECESSIDADE"));
                needs.setDescription(json.getString("DESCRICAO"));
                needs.setType(json.getString("TIPO_NECE"));
                needs.setId(json.getString("ID_NECESSIDADE"));
                needs.setMetric(json.getString("UNIDADE"));

            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Adding the ONG object to the list
            needsList.add(needs);
        }
        //Notifying the adapter that data has been added or changed
        adapter.notifyDataSetChanged();
    }


    public boolean checkInternet(){
        boolean connected = false;
        ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                // connected to wifi
                rv.setVisibility(View.VISIBLE);
                connectionViewFailed.setVisibility(View.INVISIBLE);
                connected = true;
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                rv.setVisibility(View.VISIBLE);
                connectionViewFailed.setVisibility(View.INVISIBLE);
                connected = true;
            }
        } else {
            // not connected to the internet
            rv.setVisibility(View.GONE);
            connectionViewFailed.setVisibility(View.VISIBLE);
            connected = false;
        }
        return connected;
    }

}
