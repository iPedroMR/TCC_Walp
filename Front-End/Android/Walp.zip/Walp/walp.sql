-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2017 at 04:29 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `walp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tab_doacao`
--

CREATE TABLE `tab_doacao` (
  `ID_DOACAO` int(9) NOT NULL,
  `ID_USUARIO` int(11) NOT NULL,
  `ID_ONG` int(6) NOT NULL,
  `OBJ_DOACAO` int(100) NOT NULL,
  `QTD_DOACAO` int(10) NOT NULL,
  `DATA_DOACAO` int(10) NOT NULL,
  `PONT_DOACAO` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tab_necessidade`
--

CREATE TABLE `tab_necessidade` (
  `ID_NECESSIDADE` int(4) NOT NULL,
  `NECESSIDADE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tab_ong`
--

CREATE TABLE `tab_ong` (
  `ID_ONG` int(6) NOT NULL,
  `NOME_ONG` varchar(250) NOT NULL,
  `LOGO_ONG` text NOT NULL,
  `NECESSIDADE_ONG` varchar(50) NOT NULL,
  `TELFIXO_ONG` int(20) NOT NULL,
  `TELCEL_ONG` int(20) DEFAULT NULL,
  `ENDERECO_ONG` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tab_usuario`
--

CREATE TABLE `tab_usuario` (
  `ID_USUARIO` int(11) NOT NULL,
  `NOME_USUARIO` varchar(50) NOT NULL,
  `SOBRENOME_USUARIO` varchar(250) NOT NULL,
  `EMAIL_USUARIO` varchar(200) NOT NULL,
  `SENHA_USUARIO` varchar(16) NOT NULL,
  `TKFACEBOOK_USUARIO` varchar(260) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tab_doacao`
--
ALTER TABLE `tab_doacao`
  ADD PRIMARY KEY (`ID_DOACAO`);

--
-- Indexes for table `tab_necessidade`
--
ALTER TABLE `tab_necessidade`
  ADD PRIMARY KEY (`ID_NECESSIDADE`);

--
-- Indexes for table `tab_ong`
--
ALTER TABLE `tab_ong`
  ADD PRIMARY KEY (`ID_ONG`);

--
-- Indexes for table `tab_usuario`
--
ALTER TABLE `tab_usuario`
  ADD PRIMARY KEY (`ID_USUARIO`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tab_doacao`
--
ALTER TABLE `tab_doacao`
  MODIFY `ID_DOACAO` int(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tab_necessidade`
--
ALTER TABLE `tab_necessidade`
  MODIFY `ID_NECESSIDADE` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tab_ong`
--
ALTER TABLE `tab_ong`
  MODIFY `ID_ONG` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tab_usuario`
--
ALTER TABLE `tab_usuario`
  MODIFY `ID_USUARIO` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
