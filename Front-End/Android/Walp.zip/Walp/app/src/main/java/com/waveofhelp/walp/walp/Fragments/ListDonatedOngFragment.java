package com.waveofhelp.walp.walp.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.waveofhelp.walp.walp.Activity.WelcomeActivity;
import com.waveofhelp.walp.walp.Adapters.RVDLAdapter;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.Objects.DonationList;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListDonatedOngFragment extends Fragment implements View.OnClickListener {

    private static final int MY_PERMISSION_REQUEST_CODE = 0;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 0;
    private List<DonationList> donationList;
    private String id_donation;
    private LinearLayout contentWarning;
    protected SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayout linearLayoutWarningAccount;
    RVDLAdapter adapter;
    RequestQueue queue;
    private boolean loggedIn;
    private ProgressBar progressBar;
    public LinearLayout connectionViewFailed;
    public RecyclerView rv;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    public ListDonatedOngFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_list_donated, container, false);

        linearLayoutWarningAccount = rootView.findViewById(R.id.ll_warning_account_2);

        linearLayoutWarningAccount.setOnClickListener(this);

        //SWIPE LAYOUT
        mSwipeRefreshLayout = rootView.findViewById(R.id.srl_swipe);

        contentWarning = rootView.findViewById(R.id.ll_warning_content_2);

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        loggedIn = sharedPreferences.getBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

        if(loggedIn) {

            connectionViewFailed = rootView.findViewById(R.id.connection_failed);

            connectionViewFailed.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (checkInternet()) {
                        getData();
                    } else {
                        Toast.makeText(getContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                    }
                }
            });

            if(checkInternet()) {

                rv = rootView.findViewById(R.id.rv);

                progressBar = rootView.findViewById(R.id.progressBar);

                mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        mSwipeRefreshLayout.setRefreshing(true);
                        //AÇÃO SWIPE REFRESH LAYOUT
                        if (checkInternet()) {
                            getData();
                        }
                        mSwipeRefreshLayout.setRefreshing(false);
                    }
                });

                LinearLayoutManager llm = new LinearLayoutManager(getContext());
                rv.setLayoutManager(llm);

                //Initializing our list
                donationList = new ArrayList<>();
                queue = Volley.newRequestQueue(getContext());

                //initializing our adapter
                adapter = new RVDLAdapter(donationList, getContext());

                //Adding adapter to recyclerview
                rv.setAdapter(adapter);

            }else {
                mSwipeRefreshLayout.setVisibility(View.GONE);
                connectionViewFailed.setVisibility(View.VISIBLE);
            }
        }else {
            mSwipeRefreshLayout.setVisibility(View.GONE);
            linearLayoutWarningAccount.setVisibility(View.VISIBLE);
        }

        return rootView;
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getContext());
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode,
                        getActivity(), PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Toast.makeText(getContext(), "This device is not supported", Toast.LENGTH_LONG).show();
            }
            return false;
        }
        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        if(loggedIn) {
            getData();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (checkPlayServices()) {
                        getData();
                    }
                    break;
                }
        }
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getContext()).getRequestQueue();

        String id;

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        //Volley's inbuilt class to make Json array request
        String url = Constants.URL_FEED_DONATED_ONG;
        return new JsonArrayRequest(url + "?id_ong=" + id, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {

                //Calling method parseData to parse the json response
                if(!response.toString().equals("[]")) {
                    contentWarning.setVisibility(View.GONE);
                    mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                    try {
                            parseData(response);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else {
                    mSwipeRefreshLayout.setVisibility(View.GONE);
                    contentWarning.setVisibility(View.VISIBLE);
                    connectionViewFailed.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        });
    }

    //This method will get data from the web api
    private void getData() {
        donationList.clear();
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {

            progressBar.setVisibility(View.GONE);
            //Creating the superhero object
            //Needs needs = new Needs();
            DonationList donationList2 = new DonationList();
            JSONObject json;
            try {
                //Getting json
                json = array.getJSONObject(i);

                //Adding data to the ONG object
                donationList2.setNAME_DONATION((json.getString("OBJ_DOACAO")));
                donationList2.setSTATUS_DONATION(json.getString("SITUACAO"));
                donationList2.setNAME_ONG(json.getString("NOME"));
                donationList2.setQUANTITY_DONATION(json.getString("QTD_DOACAO"));
                donationList2.setIMAGEM_ONG(json.getString("IMG_USER"));
                donationList2.setID_DONATION(json.getString("ID_DOACAO"));

            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Adding the ONG object to the list
            donationList.add(donationList2);
        }
        //Notifying the adapter that data has been added or changed
        adapter.notifyDataSetChanged();
    }


    public boolean checkInternet() {
        boolean connected = false;
        ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                // connected to wifi
                mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                connectionViewFailed.setVisibility(View.INVISIBLE);
                connected = true;
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                mSwipeRefreshLayout.setVisibility(View.VISIBLE);
                connectionViewFailed.setVisibility(View.INVISIBLE);
                connected = true;
            }
        } else {
            // not connected to the internet
            mSwipeRefreshLayout.setVisibility(View.GONE);
            connectionViewFailed.setVisibility(View.VISIBLE);
            connected = false;
        }
        return connected;
    }

    @Override
    public void onClick(View v) {
        if(v == linearLayoutWarningAccount){
            Intent intent = new Intent(getContext(), WelcomeActivity.class);
            startActivity(intent);
        }
    }
}
