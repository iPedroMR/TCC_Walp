package com.waveofhelp.walp.walp.Activity.SignUpOngActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.location.Geocoder;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.waveofhelp.walp.walp.Activity.MainOngActivity;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.MaskEditUtil;
import com.waveofhelp.walp.walp.R;
import com.waveofhelp.walp.walp.ValidaCNPJ;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.waveofhelp.walp.walp.Constants.URL_REGISTER_ONG;

/**
 * A login screen that offers login via email/password.
 */
public class SignupOngActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mPasswordView, mNameView, mEmailView, mAddressView, mPhoneView, mPasswordConfirmView, mZipCode, mComplementoView, mNeighbourView, mCityView, mNumberView, mCNPJ;
    private Spinner spStates, spOngType;
    private ImageButton buttonRegister;
    private CircleImageView buttonChoose;
    private int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private Util util;
    private AnimationDrawable animationDrawable;
    private ImageView notifierPhoto;
    private String email_ONG, senha_ONG, nome_ONG, tel_ONG, tipo_ONG, image, numero_ONG, cep_ONG, complemento_ONG, rua_ONG, cidade_ONG, estado_ONG, bairro_ONG, CNPJ;
    private ProgressBar progressBarStreet, progressBarComplemento, progressBarBairro, progressBarCidade, progressBarEstado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_ong);

        ScrollView scrollView = findViewById(R.id.registerBack);

        animationDrawable = (AnimationDrawable) scrollView.getBackground();
        animationDrawable.setEnterFadeDuration(100);
        animationDrawable.setExitFadeDuration(5000);

        // Set up the login form.
        mEmailView = findViewById(R.id.email);

        mNameView = findViewById(R.id.name);

        mAddressView = findViewById(R.id.et_street);

        mPhoneView = findViewById(R.id.phone);

        mCityView = findViewById(R.id.et_city);

        mNeighbourView = findViewById(R.id.et_neighbor);

        mCNPJ = findViewById(R.id.cnpj);

        mNumberView = findViewById(R.id.et_number);

        mComplementoView = findViewById(R.id.et_complement);

        mPasswordView = findViewById(R.id.password);

        progressBarStreet = findViewById(R.id.progressBarStreet);

        progressBarComplemento = findViewById(R.id.progressBarComplement);

        progressBarBairro = findViewById(R.id.progressBarBairro);

        progressBarCidade = findViewById(R.id.progressBarCity);

        progressBarEstado = findViewById(R.id.progressBarState);

        //mCNPJ.addTextChangedListener(MaskEditUtil.mask(mCNPJ, MaskEditUtil.FORMAT_CNPJ));

        mZipCode = findViewById(R.id.zip_code);
        mZipCode.addTextChangedListener(new ZipCodeListener(this));
        util = new Util(this, R.id.et_street,
                R.id.et_complement,
                R.id.et_neighbor,
                R.id.et_city,
                R.id.sp_state);

        mPasswordConfirmView = findViewById(R.id.password_confirm);

        buttonRegister = findViewById(R.id.buttonRegister);

        buttonChoose = findViewById(R.id.logoButton);

        notifierPhoto = findViewById(R.id.iconPhoto);

        spStates = findViewById(R.id.sp_state);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.states, android.R.layout.simple_spinner_item);

        spStates.setAdapter(adapter);

        spStates.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                ((TextView) parentView.getChildAt(0)).setTextColor(Color.WHITE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        spOngType = findViewById(R.id.sp_ong_type);

        ArrayAdapter<CharSequence> adapterOngType = ArrayAdapter.createFromResource(this, R.array.types, android.R.layout.simple_spinner_dropdown_item);

        spOngType.setAdapter(adapterOngType);

        spOngType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                ((TextView) parentView.getChildAt(0)).setTextColor(Color.WHITE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        buttonRegister.setOnClickListener(this);

        buttonChoose.setOnClickListener(this);

    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    private void registerUser() {
        email_ONG = mEmailView.getText().toString().trim();
        senha_ONG = mPasswordView.getText().toString().trim();
        nome_ONG = mNameView.getText().toString().trim();
        tel_ONG = mPhoneView.getText().toString().trim();
        cep_ONG = mZipCode.getText().toString().trim();
        rua_ONG = mAddressView.getText().toString().trim();
        complemento_ONG = mComplementoView.getText().toString().trim();
        bairro_ONG = mNeighbourView.getText().toString().trim();
        cidade_ONG = mCityView.getText().toString().trim();
        estado_ONG = spStates.getSelectedItem().toString().trim();
        numero_ONG = mNumberView.getText().toString().trim();
        tipo_ONG = spOngType.getSelectedItem().toString().trim();
        if (bitmap == null) {
            image = "";
        } else {
            image = getStringImage(bitmap);
        }
        CNPJ = mCNPJ.getText().toString().trim();

        final ProgressDialog progressDialog = new ProgressDialog(SignupOngActivity.this,
                R.style.Theme_AppCompat_DayNight_Dialog_MinWidth);
        progressDialog.setMessage("Registrando...");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGISTER_ONG,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.equalsIgnoreCase("false")) {
                            //If the server response is not success
                            //Displaying an error message on toast
                            //Toast.makeText(SignupOngActivity.this, "Email já cadastrado", Toast.LENGTH_LONG).show();
                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                            progressDialog.dismiss();
                            onRegisterFailed();
                        } else {

                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                            onRegisterSuccess();

                            //Creating a shared preference
                            SharedPreferences sharedPreferences = SignupOngActivity.this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                            //Creating editor to store values to shared preferences
                            SharedPreferences.Editor editor = sharedPreferences.edit();

                            //Adding values to editor
                            editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, true);
                            editor.putString(Constants.EMAIL_SHARED_PREF, email_ONG);
                            editor.putString(Constants.ID_SHARED_PREF, response);
                            editor.putString(Constants.USER_TYPE_SHARED_PREF, "2");

                            editor.apply();

                            progressDialog.dismiss();

                            //Starting profile activity
                            Intent intent = new Intent(SignupOngActivity.this, MainOngActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                        Toast.makeText(SignupOngActivity.this, "Verifique se o CEP corresponde ao endereço", Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                        onRegisterFailed();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();

                params.put("nome_ONG", nome_ONG);
                params.put("logo_ONG", image);
                params.put("tel_ONG", tel_ONG);
                params.put("cep_ONG", cep_ONG);
                params.put("cidade_ONG", cidade_ONG);
                params.put("estado_ONG", estado_ONG);
                params.put("rua_ONG", rua_ONG);
                params.put("numero_ONG", numero_ONG);
                params.put("bairro_ONG", bairro_ONG);
                params.put("complemento_ONG", complemento_ONG);
                params.put("senha_ONG", senha_ONG);
                params.put("email_ONG", email_ONG);
                params.put("tipo_ONG", tipo_ONG);
                params.put("cnpj_ONG", CNPJ);

                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showFileChooser() {

        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");

        Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent chooserIntent = Intent.createChooser(getIntent, "Selecione a imagem");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickIntent});

        startActivityForResult(chooserIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                buttonChoose.setImageBitmap(bitmap);
                notifierPhoto.setImageResource(0);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onClick(View v) {

        if (v == buttonRegister) {
            if (!validate()) {
                buttonEnabled();
            } else {
                buttonDisabled();
                registerUser();
            }
        }

        if (v == buttonChoose) {
            showFileChooser();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        animationDrawable.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (animationDrawable != null && animationDrawable.isRunning())
            animationDrawable.stop();
    }

    public void onRegisterSuccess() {

        buttonEnabled();
        finish();
    }

    public void onRegisterFailed() {
        buttonEnabled();
    }

    public void buttonDisabled() {
        buttonRegister.setEnabled(false);
        buttonRegister.setAlpha(0.6f);
    }

    public void buttonEnabled() {
        buttonRegister.setEnabled(true);
        buttonRegister.setAlpha(1.0f);
    }

    public boolean validate() {

        boolean valid = true;

        email_ONG = mEmailView.getText().toString();
        senha_ONG = mPasswordView.getText().toString();
        nome_ONG = mNameView.getText().toString();
        tel_ONG = mPhoneView.getText().toString();
        tipo_ONG = spOngType.getSelectedItem().toString().trim();
        cep_ONG = mZipCode.getText().toString().trim();
        rua_ONG = mAddressView.getText().toString().trim();
        bairro_ONG = mNeighbourView.getText().toString().trim();
        cidade_ONG = mCityView.getText().toString().trim();
        estado_ONG = spStates.getSelectedItem().toString().trim();
        numero_ONG = mNumberView.getText().toString().trim();
        CNPJ = mCNPJ.getText().toString().trim();

        final String confirmar_senha = mPasswordConfirmView.getText().toString();


        ImageView notifierIcon = findViewById(R.id.iconPhoto);

        if (email_ONG.isEmpty() || email_ONG.length() < 7) {
            mEmailView.setError("Entre com um endereço de e-mail válido");
            valid = false;
        } else {
            mEmailView.setError(null);
        }

        if (nome_ONG.isEmpty() || nome_ONG.length() < 3) {
            mNameView.setError("Entre com um nome válido");
            valid = false;
        } else {
            mNameView.setError(null);
        }

        if (cep_ONG.isEmpty()) {
            mZipCode.setError("Entre com um CEP");
            valid = false;
        } else {
            mZipCode.setError(null);
        }

        if (rua_ONG.isEmpty()) {
            mAddressView.setError("Entre com uma Rua");
            valid = false;
        } else {
            mAddressView.setError(null);
        }

        if (bairro_ONG.isEmpty()) {
            mNeighbourView.setError("Entre com um Bairro");
            valid = false;
        } else {
            mNeighbourView.setError(null);
        }

        if (cidade_ONG.isEmpty()) {
            mCityView.setError("Entre com um Bairro");
            valid = false;
        } else {
            mCityView.setError(null);
        }

        if (numero_ONG.isEmpty() || numero_ONG.length() < 2) {
            mNumberView.setError("Entre com um Número");
            valid = false;
        } else {
            mNumberView.setError(null);
        }

        if (estado_ONG.isEmpty() || estado_ONG.equals("Estado")) {
            valid = false;
        }

        if (tipo_ONG.isEmpty() || tipo_ONG.equals("Causa")) {
            valid = false;
        }

        if (bitmap == null) {
            //Toast.makeText(SignupOngActivity.this,"Entre com uma foto de perfil",Toast.LENGTH_LONG).show();
            valid = true;
        } else {
            notifierIcon.setImageResource(0);
        }

        if (senha_ONG.isEmpty() || senha_ONG.length() <= 4) {
            mPasswordView.setError("A senha deve ser maior do que quatro caracteres");
            valid = false;
        } else {
            mPasswordView.setError(null);
        }

        if (tel_ONG.isEmpty() || tel_ONG.length() < 8) {
            mPhoneView.setError("Entre com um número válido");
            valid = false;
        } else {
            mPhoneView.setError(null);
        }

        if (!ValidaCNPJ.isCNPJ(CNPJ) || CNPJ.isEmpty()) {
            //mCNPJ.setError("Entre com um CNPJ válido");
            valid = true;
        } else {
            mCNPJ.setError(null);
        }

        if (confirmar_senha.isEmpty() || senha_ONG.isEmpty()) {
            mPasswordConfirmView.setError("Preencha todos os campos");
            valid = false;
        } else if (!confirmar_senha.equals(senha_ONG)) {
            mPasswordConfirmView.setError("As senhas não batem");
            valid = false;
        } else {
            mPasswordConfirmView.setError(null);
        }

        return valid;
    }

    private String getZipCode() {
        return mZipCode.getText().toString();
    }

    public String getUriRequest() {
        return "https://viacep.com.br/ws/" + getZipCode() + "/json/";
    }

    public void lockFields(boolean isToLock) {
        //Set charge visible
        spStates.setVisibility(View.GONE);
        mAddressView.setVisibility(View.GONE);
        mComplementoView.setVisibility(View.GONE);
        mNeighbourView.setVisibility(View.GONE);
        mCityView.setVisibility(View.GONE);

        progressBarStreet.setVisibility(View.VISIBLE);
        progressBarComplemento.setVisibility(View.VISIBLE);
        progressBarBairro.setVisibility(View.VISIBLE);
        progressBarCidade.setVisibility(View.VISIBLE);
        progressBarEstado.setVisibility(View.VISIBLE);
        util.lockFields(isToLock);
    }

    public void setAddressFields(Address address) {

        //Set charge visible
        progressBarStreet.setVisibility(View.GONE);
        progressBarComplemento.setVisibility(View.GONE);
        progressBarBairro.setVisibility(View.GONE);
        progressBarCidade.setVisibility(View.GONE);

        spStates.setVisibility(View.VISIBLE);
        mAddressView.setVisibility(View.VISIBLE);
        mComplementoView.setVisibility(View.VISIBLE);
        mNeighbourView.setVisibility(View.VISIBLE);
        mCityView.setVisibility(View.VISIBLE);

        setField(R.id.et_street, address.getLogradouro());
        setField(R.id.et_complement, address.getComplemento());
        setField(R.id.et_neighbor, address.getBairro());
        setField(R.id.et_city, address.getLocalidade());
        setSpinner(R.id.sp_state, R.array.states, address.getUf());
    }

    private void setField(int fieldId, String data) {

        ((EditText) findViewById(fieldId)).setText(data);
    }

    //public void getLocationFromAddress(String strAddress)
    //{
        //Create coder with Activity context - this
    //    Geocoder coder = new Geocoder(this);

    //    try {
            //Get latLng from String
    //        address = coder.getFromLocationName(strAddress,5);

            //check for null
    //        if (address == null) {
    //            return;
    //        }

            //Lets take first possibility from the all possibilities.
    //        Address location=address.get(0);
    //        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

    //    } catch (IOException e)
    //    {
    //        e.printStackTrace();
    //    }
    //}


    private void setSpinner(int fieldId, int arrayId, String uf) {
        Spinner spinner = findViewById(fieldId);
        String[] states = getResources().getStringArray(arrayId);

        progressBarEstado.setVisibility(View.GONE);
        spStates.setVisibility(View.VISIBLE);

        for (int i = 0; i < states.length; i++) {
            if (states[i].equals(uf)) {
                spinner.setSelection(i);
                break;
            }
        }
    }
}