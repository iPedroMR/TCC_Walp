package com.waveofhelp.walp.walp.Fragments.ProfileOngFragments;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Activity.ThankActivity;
import com.waveofhelp.walp.walp.Activity.WelcomeActivity;
import com.waveofhelp.walp.walp.Adapters.RVNSAdapter;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.Objects.Needs;
import com.waveofhelp.walp.walp.OnEditTextChanged;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NeedsFragment extends Fragment implements View.OnClickListener {

    Integer[] enteredNumber = new Integer[1000];
    String[] nameNeed = new String[1000];
    private List<Needs> needsList;
    private RecyclerView mRecyclerView;
    private LinearLayout warningAccount, warningContent, instructions;
    private Button buttonConfirm;
    private String id, idUser;
    String stringQuantity, stringName;
    RVNSAdapter adapter;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    RequestQueue queue;

    public NeedsFragment() {
        // Required empty public constructor
    }

    //Overriden method onCreateView
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_needs, container, false);

        mRecyclerView = rootView.findViewById(R.id.rsv);
        warningAccount = rootView.findViewById(R.id.ll_warning_account);
        warningContent = rootView.findViewById(R.id.ll_warning_content);
        instructions = rootView.findViewById(R.id.instructions);
        buttonConfirm = rootView.findViewById(R.id.button_confirm_donation);

        buttonConfirm.setOnClickListener(this);
        warningAccount.setOnClickListener(this);


        Bundle bundle = this.getArguments();
        id = bundle.getString("id");

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        idUser = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        if (verifyDonationPossibility()) {

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());

            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

            mRecyclerView.setHasFixedSize(true);

            mRecyclerView.setLayoutManager(linearLayoutManager);

            //Initializing our list
            needsList = new ArrayList<>();
            queue = Volley.newRequestQueue(getContext());

            //Calling method to get data to fetch data
            getData();

            //initializing our adapter
            adapter = new RVNSAdapter(needsList, getContext(), new OnEditTextChanged() {
                @Override
                public void onTextChanged(int position, String charSeq, String nameObj) {
                    Log.d("TAG", "position " + position + " " + charSeq + "" + nameObj);

                    if (charSeq.equals("") || charSeq.equals("0")) {
                        nameNeed[position] = null;
                        enteredNumber[position] = null;
                    } else {
                        enteredNumber[position] = Integer.valueOf(charSeq);
                        nameNeed[position] = nameObj;
                    }
                }
            });

            //Adding adapter to recyclerview
            mRecyclerView.setAdapter(adapter);

        }

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        return rootView;
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getContext()).getRequestQueue();

        //Volley's inbuilt class to make Json array request
        String url = Constants.URL_FEED_NEED;
        return new JsonArrayRequest(url + "?id_ong=" + id, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {

                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        });
    }

    //This method will get data from the web api
    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        if (array.toString().equals("[]")) {
            mRecyclerView.setVisibility(View.GONE);
            buttonConfirm.setVisibility(View.GONE);
            instructions.setVisibility(View.GONE);
            warningContent.setVisibility(View.VISIBLE);
        } else {

            for (int i = 0; i < array.length(); i++) {

                //Creating the superhero object
                Needs needs = new Needs();
                JSONObject json;
                try {
                    //Getting json
                    json = array.getJSONObject(i);

                    //Adding data to the ONG object
                    needs.setName(json.getString("NECESSIDADE"));
                    needs.setDescription(json.getString("DESCRICAO"));
                    needs.setType(json.getString("TIPO_NECE"));
                    needs.setId(json.getString("ID_NECESSIDADE"));
                    needs.setMetric(json.getString("UNIDADE"));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //Adding the ONG object to the list
                needsList.add(needs);
            }
        }
        //Notifying the adapter that data has been added or changed
        adapter.notifyDataSetChanged();
    }

    public boolean verifyDonationPossibility() {
        boolean valid = true;

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getContext().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        boolean loggedIn = sharedPreferences.getBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

        if (!loggedIn) {
            instructions.setVisibility(View.GONE);
            mRecyclerView.setVisibility(View.GONE);
            buttonConfirm.setVisibility(View.GONE);
            warningAccount.setVisibility(View.VISIBLE);
            valid = false;
        }

        return valid;
    }

    @Override
    public void onClick(View v) {
        if (v == warningAccount) {
            Intent intent = new Intent(getContext(), WelcomeActivity.class);
            startActivity(intent);
        }

        if (v == buttonConfirm) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            View promptView = layoutInflater.inflate(R.layout.alert_dialog_confirm_donation, null);
            final AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
            Button buttonConfirmDonation, buttonCancelDonation;
            buttonConfirmDonation = promptView.findViewById(R.id.alert_button_confirm_donation);
            buttonCancelDonation = promptView.findViewById(R.id.alert_button_cancel_donation);
            buttonConfirmDonation.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    sendData();

                }
            });

            buttonCancelDonation.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    alertDialog.cancel();

                }
            });

            alertDialog.setView(promptView);
            alertDialog.show();
        }
    }

    public void sendData() {
        final ProgressDialog progressDialog = new ProgressDialog(getContext(),
                R.style.Theme_AppCompat_DayNight_Dialog_MinWidth);
        progressDialog.setMessage("Registrando...");
        progressDialog.setIndeterminate(true);
        progressDialog.show();

        for (int i = 0; i < 1000; i++) {
            if (enteredNumber[i] != null) {

                stringQuantity = enteredNumber[i].toString();

                stringName = nameNeed[i];

                String url = Constants.URL_INSERT_DONATION;
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                if (response.equalsIgnoreCase("false")) {
                                    //If the server response is not success
                                    //Displaying an error message on toast
                                    Toast.makeText(getContext(), "Tente novamente mais tarde", Toast.LENGTH_LONG).show();
                                } else {

                                    //Starting login activity
                                    Intent intent = new Intent(getContext(), ThankActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                //Dismissing the progress dialog
                            }
                        }) {

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {

                        //Converting Bitmap to String

                        Map<String, String> params = new HashMap<String, String>();
                        params.put("id_ong", id);
                        params.put("id_user", idUser);
                        params.put("qtd_doacao", stringQuantity);
                        params.put("obj_doacao", stringName);

                        return params;

                    }

                };

                stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                RequestQueue requestQueue = Volley.newRequestQueue(getContext());
                requestQueue.add(stringRequest);
            }
        }
        progressDialog.dismiss();
    }
}