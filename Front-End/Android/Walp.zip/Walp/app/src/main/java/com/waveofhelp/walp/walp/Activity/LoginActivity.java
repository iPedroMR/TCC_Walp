package com.waveofhelp.walp.walp.Activity;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.R;

import java.util.HashMap;
import java.util.Map;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    //Defining views
    private EditText editTextEmail;
    private EditText editTextPassword;
    private ImageButton buttonLogin;
    private TextView errorAdvisor;
    private ProgressBar progressBar;

    //boolean variable to check user is logged in or not
    //initially it is false
    private boolean loggedIn = false;
    private AnimationDrawable animationDrawable;
    private RelativeLayout relativeLayout;

    final String SiteKey = "6LfMHigUAAAAAA1658VGlUKz2uzlPV3V3JR3Kbn6";
    final String SecretKey = "6LfMHigUAAAAAGhpbxWtc-dmO-wjZHQt2AbdzlsZ";

    private GoogleApiClient mGoogleApiClient;

    private int ATTEMPTS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        relativeLayout = findViewById(R.id.registerBack);
        progressBar = findViewById(R.id.progressBar);

        //NÃO EXIBIR O TECLADO AUTOMÁTICAMENTE
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        animationDrawable = (AnimationDrawable) relativeLayout.getBackground();
        animationDrawable.setEnterFadeDuration(100);
        animationDrawable.setExitFadeDuration(5000);

        TextView tx = findViewById(R.id.logoSignin);
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/Bello-Pro.ttf");
        tx.setTypeface(custom_font);

        //Initializing views
        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);

        buttonLogin = findViewById(R.id.buttonLogin);

        //Adding click listener
        buttonLogin.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        animationDrawable.start();
        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        loggedIn = sharedPreferences.getBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

        //If we will get true
        if (loggedIn) {
            //We will start the Profile Activity
            Intent intent = new Intent(LoginActivity.this, MainUserActivity.class);
            startActivity(intent);
        }
    }

    private void login() {
        //Getting values from edit texts
        final String user = editTextEmail.getText().toString().trim();
        final String senha = editTextPassword.getText().toString().trim();
        final String id;
        final String type;

        ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", 0, 100); // see this max value coming back here, we animale towards that value
        animation.setDuration(5000); //in milliseconds
        animation.setInterpolator(new DecelerateInterpolator());
        progressBar.setVisibility(View.VISIBLE);
        animation.start();

        //Creating a string request
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //If we are getting success from server

                        if (response.equalsIgnoreCase("false")) {
                            //If the server response is not success
                            //Displaying an error message on toast
                            progressBar.clearAnimation();
                            progressBar.setVisibility(View.GONE);
                            onLoginFailed();

                            errorAdvisor = findViewById(R.id.advisorError);

                            errorAdvisor.setText("E-mail ou senha inválido");
                            errorAdvisor.setVisibility(View.VISIBLE);

                            errorAdvisor.postDelayed(new Runnable() {
                                public void run() {
                                    errorAdvisor.setVisibility(View.INVISIBLE);
                                }
                            }, 3000);

                            ATTEMPTS++;

                        } else {
                            onLoginSuccess();
                            //Creating a shared preference
                            SharedPreferences sharedPreferences = LoginActivity.this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                            //Creating editor to store values to shared preferences
                            SharedPreferences.Editor editor = sharedPreferences.edit();

                            //Adding values to editor
                            editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, true);
                            editor.putString(Constants.EMAIL_SHARED_PREF, user);
                            editor.putBoolean(Constants.LOGIN_ATTEMPTS, false);
                            editor.putString(Constants.ID_SHARED_PREF, response.substring(1, response.length()));
                            editor.putString(Constants.USER_TYPE_SHARED_PREF, response.substring(0, 1));

                            //Saving values to editor
                            editor.apply();

                            progressBar.clearAnimation();
                            progressBar.setVisibility(View.GONE);

                            if (response.substring(0, 1).equals("1")) {

                                Intent intent = new Intent(LoginActivity.this, MainUserActivity.class);
                                startActivity(intent);

                            }
                            if (response.substring(0, 1).equals("2")) {
                                Intent intent = new Intent(LoginActivity.this, MainOngActivity.class);
                                startActivity(intent);
                            }

                            ATTEMPTS = 0;
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        //progressDialog.dismiss();
                        //onLoginFailed();
                        //Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                params.put("user", user);
                params.put("senha", senha);

                params.put(Constants.EMAIL_SHARED_PREF, user);
                params.put(Constants.KEY_PASSWORD, senha);

                //returning parameter
                return params;
            }
        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    public void onClick(View v) {


        Log.i("ATTEMPTS", "ATTEMPTS VALUE: " + ATTEMPTS);
        SharedPreferences sharedPreferences = LoginActivity.this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        //Creating editor to store values to shared preferences
        SharedPreferences.Editor editor = sharedPreferences.edit();


        //Fetching the boolean value form sharedpreferences
        boolean configAttempts = sharedPreferences.getBoolean(Constants.LOGIN_ATTEMPTS, false);

        if (!validate()) {
            onLoginFailed();
        } else if (!configAttempts) {
            if (ATTEMPTS < 3) {
                buttonLogin.setEnabled(false);
                login();
            } else {
                editor.putBoolean(Constants.LOGIN_ATTEMPTS, true);
                editor.apply();
                captchaResolve();
            }
        } else {
            editor.putBoolean(Constants.LOGIN_ATTEMPTS, true);
            editor.commit();
            captchaResolve();
        }
    }

    public void forgotPassword(View view) {
        Toast.makeText(LoginActivity.this, "Enviando para a web", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (animationDrawable != null && animationDrawable.isRunning())
            animationDrawable.stop();
    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
        startActivity(intent);
    }

    public void onLoginSuccess() {
        buttonLogin.setEnabled(true);
        //finish();
    }

    public void captchaResolve() {
        callConection();
        SafetyNet.SafetyNetApi.verifyWithRecaptcha(mGoogleApiClient, "6LfMHigUAAAAAA1658VGlUKz2uzlPV3V3JR3Kbn6")
                .setResultCallback(new ResultCallback<SafetyNetApi.RecaptchaTokenResult>() {
                    @Override
                    public void onResult(SafetyNetApi.RecaptchaTokenResult result) {
                        Status status = result.getStatus();

                        if ((status != null) && status.isSuccess()) {

                            buttonLogin.setEnabled(false);
                            login();

                            if (!result.getTokenResult().isEmpty()) {
                                onLoginFailed();
                            }
                        } else {

                            Log.e("MY_APP_TAG", "Error occurred " +
                                    "when communicating with the reCAPTCHA service.");

                            // Use status.getStatusCode() to determine the exact
                            // error code. Use this code in conjunction with the
                            // information in the "Handling communication errors"
                            // section of this document to take appropriate action
                            // in your app.
                        }
                    }
                });
    }

    public void onLoginFailed() {
        buttonLogin.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Entre com um endereço de e-mail válido");
            valid = false;
        } else {
            editTextEmail.setError(null);
        }

        if (password.isEmpty() || password.length() < 4) {
            editTextPassword.setError("A senha deve ser maior do que quatro caracteres");
            valid = false;
        } else {
            editTextPassword.setError(null);
        }

        return valid;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        //Toast.makeText(this, "Conectado", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Toast.makeText(this,
                "onConnectionSuspended: " + i,
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this,
                "onConnectionFailed():\n" + connectionResult.getErrorMessage(),
                Toast.LENGTH_LONG).show();
    }

    private synchronized void callConection() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(SafetyNet.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();

        mGoogleApiClient.connect();
    }
}

