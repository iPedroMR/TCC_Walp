package com.waveofhelp.walp.walp.Objects;

/**
 * Created by beta17 on 22/10/17.
 */

public class DonationList {
    private String ID_DONATION;
    private String NAME_DONATION;
    private String QUANTITY_DONATION;
    private String IMAGEM_ONG;
    private String NAME_ONG;
    private String STATUS_DONATION;

    public String getID_DONATION() {
        return ID_DONATION;
    }

    public void setID_DONATION(String ID_DONATION) {
        this.ID_DONATION = ID_DONATION;
    }

    public String getNAME_DONATION() {
        return NAME_DONATION;
    }

    public void setNAME_DONATION(String NAME_DONATION) {
        this.NAME_DONATION = NAME_DONATION;
    }

    public String getQUANTITY_DONATION() {
        return QUANTITY_DONATION;
    }

    public void setQUANTITY_DONATION(String QUANTITY_DONATION) {
        this.QUANTITY_DONATION = QUANTITY_DONATION;
    }

    public String getIMAGEM_ONG() {
        return IMAGEM_ONG;
    }

    public void setIMAGEM_ONG(String IMAGEM_ONG) {
        this.IMAGEM_ONG = IMAGEM_ONG;
    }

    public String getNAME_ONG() {
        return NAME_ONG;
    }

    public void setNAME_ONG(String NAME_ONG) {
        this.NAME_ONG = NAME_ONG;
    }

    public String getSTATUS_DONATION() {
        return STATUS_DONATION;
    }

    public void setSTATUS_DONATION(String STATUS_DONATION) {
        this.STATUS_DONATION = STATUS_DONATION;
    }
}
