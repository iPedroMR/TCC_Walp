package com.waveofhelp.walp.walp.Activity;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.MaskEditUtil;
import com.waveofhelp.walp.walp.NetworkControllers.CustomVolleyRequest;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileSettingsActivity extends AppCompatActivity implements View.OnClickListener {
    private AnimationDrawable animationDrawable;
    private Dialog dialog;
    private RelativeLayout userPhoto;
    private LinearLayout linearLayout;
    private RequestQueue queue;
    private Bitmap bitmap;
    private Button removeButton;
    private int PICK_IMAGE_REQUEST = 1;
    private String url = Constants.URL_PERFIL_USER;
    private String urlSendData = Constants.URL_UPDATE_USER;
    private String urlDeleteAccount = Constants.URL_DELETE_USER;
    private CircleImageView circleImageView;
    private EditText etName, etSurname, etPhone, etEmail;
    //DATA GET
    private String phoneUser, emailUser, nameUser, surnameUser, imageUser, id;
    private ImageButton buttonUpdate;
    private ProgressBar progressBar;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_settings);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle("");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        final Drawable upArrow = getResources().getDrawable(R.drawable.abc_ic_ab_back_material);
        upArrow.setColorFilter(getResources().getColor(R.color.cardview_light_background), PorterDuff.Mode.SRC_ATOP);
        getSupportActionBar().setHomeAsUpIndicator(upArrow);


        linearLayout = findViewById(R.id.linear_layout);
        animationDrawable = (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(100);
        animationDrawable.setExitFadeDuration(5000);
        removeButton = findViewById(R.id.remove_button);

        circleImageView = findViewById(R.id.profile_photo);
        etName = findViewById(R.id.name);
        etSurname = findViewById(R.id.surname);
        etPhone = findViewById(R.id.textPhone);
        etEmail = findViewById(R.id.textEmail);
        progressBar = findViewById(R.id.progress_bar);

        etPhone.addTextChangedListener(MaskEditUtil.mask(etPhone, MaskEditUtil.FORMAT_FONE));

        buttonUpdate = findViewById(R.id.button_update);
        userPhoto = findViewById(R.id.user_photo);

        etName.setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence cs, int start,
                                               int end, Spanned spanned, int dStart, int dEnd) {
                        if (cs.toString().matches("[a-zA-Z]+")) {
                            return cs;
                        }
                        return "";
                    }
                }
        });

        etSurname.setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence cs, int start,
                                               int end, Spanned spanned, int dStart, int dEnd) {
                        // TODO Auto-generated method stub
                        if (cs.toString().matches("[a-zA-Z]+")) {
                            return cs;
                        }
                        return "";
                    }
                }
        });


        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        removeButton.setOnClickListener(this);
        userPhoto.setOnClickListener(this);
        buttonUpdate.setOnClickListener(this);
        queue = Volley.newRequestQueue(this);
        getData();
        disableButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        animationDrawable.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (animationDrawable != null && animationDrawable.isRunning())
            animationDrawable.stop();
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getApplicationContext()).getRequestQueue();

        //Volley's inbuilt class to make Json array request
        return new JsonArrayRequest(Request.Method.GET, url + "?id_user=" + id, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        }) {
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    String jsonString = new String(response.data,
                            HttpHeaderParser
                                    .parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString),
                            HttpHeaderParser
                                    .parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                } catch (JSONException je) {
                    return Response.error(new ParseError(je));
                }
            }
        };
    }

    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {
            JSONObject json;
            try {
                //Getting json
                json = array.getJSONObject(i);

                //Adding data to the ONG object
                phoneUser = (json.getString("CEL_USUARIO"));
                nameUser = (json.getString("NOME_USUARIO"));
                surnameUser = (json.getString("SOBRENOME_USUARIO"));
                imageUser = (json.getString("IMG_USER"));
                emailUser = (json.getString("EMAIL_USUARIO"));

                setData();
                textWatchers();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void setData() {
        if (!phoneUser.equals("")) {
            etPhone.setText(phoneUser, TextView.BufferType.EDITABLE);
        }

        etName.setText(nameUser);
        etEmail.setText(emailUser);
        etPhone.setText(phoneUser);
        etSurname.setText(surnameUser);

        ImageLoader imageLoader = CustomVolleyRequest.getInstance(this).getImageLoader();
        imageLoader.get(imageUser, ImageLoader.getImageListener(circleImageView, R.drawable.image, android.R.drawable.ic_dialog_alert));
        Bitmap bitmapImageOng = ((BitmapDrawable) circleImageView.getDrawable()).getBitmap();
        circleImageView.setImageBitmap(bitmapImageOng);
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    @Override
    public void onClick(View view) {

        if (view == buttonUpdate) {
            progressBar.setVisibility(View.VISIBLE);
            if (validData()) {
                sendOngServerData();
            }
        }

        if (view == removeButton) {
            //Creating an alert dialog to confirm logout
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("Tem certeza que deseja remover a sua conta?");
            alertDialogBuilder.setPositiveButton("Sim",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            sendRemove();
                        }
                    });

            alertDialogBuilder.setNegativeButton("Não",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });

            //Showing the alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }

        if (view == userPhoto) {
            showFileChooser();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(ProfileSettingsActivity.this, MainUserActivity.class);
        startActivity(intent);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                bitmap = MediaStore.Images.Media.getBitmap(this.getApplicationContext().getContentResolver(), filePath);
                circleImageView.setImageBitmap(bitmap);
                enableButton();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        Intent intent = new Intent(ProfileSettingsActivity.this, MainUserActivity.class);
        startActivity(intent);
        return true;
    }

    private void showFileChooser() {

        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");

        Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent chooserIntent = Intent.createChooser(getIntent, "Selecione a imagem");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickIntent});

        startActivityForResult(chooserIntent, PICK_IMAGE_REQUEST);
    }

    private void sendOngServerData() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSendData,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //If we are getting success from server
                        if (response.equalsIgnoreCase(Constants.Success)) {
                            Toast.makeText(ProfileSettingsActivity.this, "Alteração feita com sucesso!", Toast.LENGTH_LONG).show();
                            disableButton();
                            progressBar.setVisibility(View.GONE);
                        } else if(response.equals("false")) {
                            Toast.makeText(ProfileSettingsActivity.this, "A alteração não pode ser feita!", Toast.LENGTH_LONG).show();
                            disableButton();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                        Toast.makeText(getApplicationContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                String name, surname, email, phone, image;

                name = etName.getText().toString();
                surname = etSurname.getText().toString();
                email = etEmail.getText().toString();
                phone = etPhone.getText().toString();

                if (bitmap!=null){
                    image = getStringImage(bitmap);
                }else {
                    image = imageUser;
                }

                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();

                params.put("id_user", id);
                params.put("sobrenome_user", surname);
                params.put("nome_user", name);
                params.put("email_user", email);
                params.put("cel_user", phone);
                params.put("img_user",image);

                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void textWatchers() {

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                enableButton();
            }
        };
        etName.addTextChangedListener(textWatcher);
        etSurname.addTextChangedListener(textWatcher);
        etEmail.addTextChangedListener(textWatcher);
        etPhone.addTextChangedListener(textWatcher);
    }

    private void disableButton() {
        buttonUpdate.setImageResource(0);
        buttonUpdate.setEnabled(false);
    }

    private void enableButton() {
        buttonUpdate.setImageResource(R.drawable.ic_arrow_forward_black_24dp);
        buttonUpdate.setEnabled(true);
    }

    private boolean validData() {
        boolean valid = true;

        if (emailUser.isEmpty() || emailUser.length() < 7) {
            etEmail.setError("Entre com um endereço de e-mail válido");
            valid = false;
        } else {
            etEmail.setError(null);
        }
        if (nameUser.isEmpty() || nameUser.length() < 3) {
            etName.setError("Entre com um nome válido");
            valid = false;
        } else {
            etName.setError(null);
        }

        if (surnameUser.isEmpty() || surnameUser.length() < 3) {
            etSurname.setError("Entre com um sobrenome válido");
            valid = false;
        } else {
            etSurname.setError(null);
        }

        return valid;
    }

    private void sendRemove() {
        String url = Constants.URL_DELETE_USER;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.equalsIgnoreCase("false")) {
                            //If the server response is not success
                            //Displaying an error message on toast
                            Toast.makeText(ProfileSettingsActivity.this, "Tente novamente mais tarde", Toast.LENGTH_LONG).show();
                        } else {
                            //Getting out sharedpreferences
                            SharedPreferences preferences = getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                            //Getting editor
                            SharedPreferences.Editor editor = preferences.edit();

                            //Puting the value false for loggedin
                            editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

                            //Putting blank value to email
                            editor.putString(Constants.EMAIL_SHARED_PREF, "");

                            editor.putString(Constants.USER_TYPE_SHARED_PREF, "0");

                            //Saving the sharedpreferences
                            editor.apply();

                            //Starting login activity
                            Intent intent = new Intent(ProfileSettingsActivity.this, LoginActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();
                params.put("id_user", id);

                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}
