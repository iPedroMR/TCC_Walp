package com.waveofhelp.walp.walp.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.Fragments.ListDonationFragment;
import com.waveofhelp.walp.walp.R;

import java.util.HashMap;
import java.util.Map;

public class EditNeedActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etName, etDescription;
    private Spinner spType,spMetric;
    private Button confirmNeed, removeNeed;
    private String textName, textDescription, textType, idNeed, textMetric;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_need);

        etName = findViewById(R.id.name);
        etDescription = findViewById(R.id.description);
        spType = findViewById(R.id.sp_need_type);
        spMetric = findViewById(R.id.sp_metric);
        confirmNeed = findViewById(R.id.button_confirm_need);
        removeNeed = findViewById(R.id.remove_button);

        Intent intentThatStartedThisActivity = getIntent();

        if (intentThatStartedThisActivity.hasExtra("name")) {
            textName = intentThatStartedThisActivity.getStringExtra("name");
            etName.setText(textName);
        }

        if (intentThatStartedThisActivity.hasExtra("description")) {
            String textDescription = intentThatStartedThisActivity.getStringExtra("description");
            etDescription.setText(textDescription);
        }

        if (intentThatStartedThisActivity.hasExtra("id")) {
            idNeed = intentThatStartedThisActivity.getStringExtra("id");
        }

        ArrayAdapter<CharSequence> adapterType = ArrayAdapter.createFromResource(this, R.array.need_type, android.R.layout.simple_spinner_dropdown_item);

        spType.setAdapter(adapterType);

        ArrayAdapter<CharSequence> adapterMetric = ArrayAdapter.createFromResource(this, R.array.unit_metrics, android.R.layout.simple_spinner_dropdown_item);

        spMetric.setAdapter(adapterMetric);

        if (intentThatStartedThisActivity.hasExtra("type")) {
            textType = intentThatStartedThisActivity.getStringExtra("type");
            spType.setSelection(adapterType.getPosition(textType));
        }

        if (intentThatStartedThisActivity.hasExtra("metric")) {
            spMetric.setSelection(adapterMetric.getPosition(intentThatStartedThisActivity.getStringExtra("metric")));
        }else{
            textMetric = "Sem unidade";
        }

        confirmNeed.setOnClickListener(this);
        removeNeed.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == confirmNeed) {
            if (verifyData()) {
                sendData();
            }
        }
            if (v == removeNeed) {
                //Creating an alert dialog to confirm logout
                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setMessage("Tem certeza que deseja remover a necessidade?");
                alertDialogBuilder.setPositiveButton("Sim",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                sendRemove();
                            }
                        });

                alertDialogBuilder.setNegativeButton("Não",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                            }
                        });

                //Showing the alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
    }

    private boolean verifyData() {

        boolean valid = true;

        textName = etName.getText().toString();
        textDescription = etDescription.getText().toString();
        textType = spType.getSelectedItem().toString().trim();
        textMetric = spMetric.getSelectedItem().toString().trim();

        if (textName.isEmpty() || textName.length() < 1) {
            etName.setError("Entre com um nome válido");
            valid = false;
        } else {
            etName.setError(null);
        }

        if (textType.isEmpty() || textType.equals("Tipo da ONG")) {
            valid = false;
        }

        if (textMetric.isEmpty() || textMetric.equals("Sem unidade")) {
            textMetric = "";
        }

        return valid;
    }

    private void sendData() {
        String url = Constants.URL_UPDATE_NEED;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.equalsIgnoreCase("false")) {
                            //If the server response is not success
                            //Displaying an error message on toast
                            Toast.makeText(EditNeedActivity.this, "Tente novamente mais tarde", Toast.LENGTH_LONG).show();
                        } else {

                            onBackPressed();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                        Toast.makeText(EditNeedActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();

                params.put("id_nece", idNeed);
                params.put("necessidade", textName);
                params.put("descricao", textDescription);
                params.put("tipo", textType);
                params.put("unidade", textMetric);

                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void sendRemove() {
        String url = Constants.URL_DELETE_NEED;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.equalsIgnoreCase("false")) {
                            //If the server response is not success
                            //Displaying an error message on toast
                            Toast.makeText(EditNeedActivity.this, "Tente novamente mais tarde", Toast.LENGTH_LONG).show();
                        } else {
                            onBackPressed();
                            Toast.makeText(EditNeedActivity.this, "Necessidade removida", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();
                params.put("id_nece", idNeed);
                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
