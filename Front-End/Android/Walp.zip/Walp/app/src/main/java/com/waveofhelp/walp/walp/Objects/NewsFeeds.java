package com.waveofhelp.walp.walp.Objects;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by Pedro on 23/05/2017.
 */

public class NewsFeeds {

    private String ID_ONG;
    private String NOME_ONG;
    private String TIPO_ONG;
    private String IMAGEM_ONG;
    private String DISTANCIA_ONG;

    public String getNOME_ONG() {
        return NOME_ONG;
    }

    public void setNOME_ONG(String NOME_ONG) {
        this.NOME_ONG = NOME_ONG;
    }

    public String getTIPO_ONG() {
        return TIPO_ONG;
    }

    public void setTIPO_ONG(String TIPO_ONG) {
        this.TIPO_ONG = TIPO_ONG;
    }

    public String getIMAGEM_ONG() {
        return IMAGEM_ONG;
    }

    public void setIMAGEM_ONG(String IMAGEM_ONG) {
        this.IMAGEM_ONG = IMAGEM_ONG;
    }

    public String getID_ONG() {
        return ID_ONG;
    }

    public void setID_ONG(String ID_ONG) {
        this.ID_ONG = ID_ONG;
    }

    public String getDISTANCIA_ONG() {
        return DISTANCIA_ONG;
    }

    public void setDISTANCIA_ONG(String DISTANCIA_ONG) {
        this.DISTANCIA_ONG = DISTANCIA_ONG;
    }
}
