package com.waveofhelp.walp.walp.Objects;

/**
 * Created by Pedro on 17/05/2017.
 */

public class Management {
    public String name;
    public String phone;
    public String donationName;
    public String data;
    public String status;
    public int userPhoto;
    public int photoDonation;

    public Management(String name, String donationName, int userPhoto, String data, String status, int photoDonation, String phone) {
        this.name = name;
        this.userPhoto = userPhoto;
        this.data = data;
        this.status = status;
        this.photoDonation = photoDonation;
        this.phone=phone;
        this.donationName=donationName;
    }
}
