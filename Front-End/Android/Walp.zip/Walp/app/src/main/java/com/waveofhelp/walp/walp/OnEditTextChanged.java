package com.waveofhelp.walp.walp;

/**
 * Created by beta17 on 21/10/17.
 */

public interface OnEditTextChanged {
    void onTextChanged(int position, String charSeq, String nameObj);
}
