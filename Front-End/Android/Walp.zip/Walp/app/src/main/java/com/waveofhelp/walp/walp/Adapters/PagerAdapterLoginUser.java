package com.waveofhelp.walp.walp.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.waveofhelp.walp.walp.Activity.LoginEmailDescription;
import com.waveofhelp.walp.walp.Activity.LoginNameDescription;
import com.waveofhelp.walp.walp.Activity.LoginPasswordDescription;

/**
 * Created by beta17 on 12/03/18.
 */

public class PagerAdapterLoginUser extends FragmentPagerAdapter {

    public PagerAdapterLoginUser(FragmentManager fm) {
        super(fm);
        // TODO Auto-generated constructor stub
    }

    @Override
    public Fragment getItem(int arg0) {
        // TODO Auto-generated method stub
        switch (arg0) {
            case 0:
                return new LoginNameDescription();
            case 1:
                return new LoginEmailDescription();
            case 2:
                return new LoginPasswordDescription();
            default:
                break;
        }
        return null;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return 3;
    }

}
