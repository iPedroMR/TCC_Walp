package com.waveofhelp.walp.walp.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Adapters.PagerAdapter;
import com.waveofhelp.walp.walp.Adapters.PagerAdapterLoginUser;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.waveofhelp.walp.walp.Constants.URL_REGISTER;

/**
 * Created by Pedro on 27/05/2017.
 */

public class SignUpUserActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mPasswordView, mNameView, mEmailView, mLastNameView, mPasswordConfirmView;
    private ImageButton buttonRegister;
    private RelativeLayout relativeLayout;
    private AnimationDrawable animationDrawable;
    private CircleImageView buttonChoose;
    private int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private ImageView notifierPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_user);

        //TabLayout tabLayout =  findViewById(R.id.tab_layout);
        //tabLayout.setupWithViewPager(viewPager, true);

        //relativeLayout = findViewById(R.id.registerBack);

        //animationDrawable =(AnimationDrawable) relativeLayout.getBackground();
        //animationDrawable.setEnterFadeDuration(100);
        //animationDrawable.setExitFadeDuration(5000);

        // Set up the login form.
        mEmailView = findViewById(R.id.email);

        mNameView = findViewById(R.id.name);

        mLastNameView = findViewById(R.id.lastName);

        mPasswordView = findViewById(R.id.password);

        mPasswordConfirmView = findViewById(R.id.password_confirm);

        buttonRegister = findViewById(R.id.buttonRegister);

        buttonChoose = findViewById(R.id.logoButton);

        notifierPhoto = findViewById(R.id.iconPhoto);

        buttonRegister.setOnClickListener(this);

        buttonChoose.setOnClickListener(this);

    }

    public String getStringImage(Bitmap bmp){
        if(bitmap == null){
            return null;
        }else{
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] imageBytes = baos.toByteArray();
            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            return encodedImage;
        }
    }

    private void registerUser(){
        final String email_user = mEmailView.getText().toString().trim();
        final String senha_user = mPasswordView.getText().toString().trim();
        final String nome_user = mNameView.getText().toString().trim();
        final String sobrenome_user = mLastNameView.getText().toString().trim();
        //Converting Bitmap to String
        final String image = getStringImage(bitmap);

        final ProgressDialog progressDialog = new ProgressDialog(SignUpUserActivity.this,
                R.style.Theme_AppCompat_DayNight_Dialog_MinWidth);
        progressDialog.setMessage("Registrando...");
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGISTER,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if(response.equalsIgnoreCase("false")){
                            //If the server response is not success
                            //Displaying an error message on toast
                            Toast.makeText(SignUpUserActivity.this,"Email já cadastrado",Toast.LENGTH_LONG).show();
                            progressDialog.dismiss();
                            onRegisterFailed();
                        } else{

                            onRegisterSuccess();

                            //Creating a shared preference
                            SharedPreferences sharedPreferences = SignUpUserActivity.this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                            //Creating editor to store values to shared preferences
                            SharedPreferences.Editor editor = sharedPreferences.edit();

                            //Adding values to editor
                            editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, true);
                            editor.putString(Constants.EMAIL_SHARED_PREF, email_user);
                            editor.putString(Constants.ID_SHARED_PREF,response);
                            editor.putString(Constants.USER_TYPE_SHARED_PREF, "1");

                            //Saving values to editor
                            editor.apply();
                            progressDialog.dismiss();



                            //Starting profile activity
                            Intent intent = new Intent(SignUpUserActivity.this, MainUserActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        onRegisterFailed();
                    }
                }){
            @Override
            protected Map<String,String> getParams() throws AuthFailureError {

                Map<String,String> params = new HashMap<String, String>();

                params.put("nome_user",nome_user);
                params.put("sobrenome_user",sobrenome_user);
                params.put("email_user",email_user);
                params.put("senha_user",senha_user);
                params.put("img_user", image);

                params.put(Constants.EMAIL_SHARED_PREF, email_user);
                params.put(Constants.KEY_PASSWORD, senha_user);
                return params;
            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void showFileChooser() {
        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");

        Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent chooserIntent = Intent.createChooser(getIntent, "Selecione a imagem");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] {pickIntent});

        startActivityForResult(chooserIntent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);

                buttonChoose.setImageBitmap(bitmap);
                notifierPhoto.setImageResource(0);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onClick(View v) {

        if(v == buttonRegister){
            if(!validate()){
                buttonEnabled();
            }else {
                buttonDisabled();
                registerUser();
            }
        }

        if(v == buttonChoose){
            showFileChooser();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //animationDrawable.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //if (animationDrawable != null && animationDrawable.isRunning())
        //    animationDrawable.stop();
    }

    public void onRegisterSuccess() {
        buttonEnabled();
        finish();
    }

    public void onRegisterFailed() {
        buttonEnabled();
    }

    public void buttonDisabled(){
        buttonRegister.setEnabled(false);
        buttonRegister.setAlpha(0.6f);
    }

    public void buttonEnabled(){
        buttonRegister.setEnabled(true);
        buttonRegister.setAlpha(1.0f);
    }

    public boolean validate() {

        boolean valid = true;

        final String email_user = mEmailView.getText().toString();
        final String senha_user = mPasswordView.getText().toString();
        final String nome_user = mNameView.getText().toString();
        final String sobrenome_user = mLastNameView.getText().toString();
        final String confirmar_senha = mPasswordConfirmView.getText().toString();

        ImageView notifierIcon = findViewById(R.id.iconPhoto);

        if (email_user.isEmpty() || email_user.length() < 7) {
             mEmailView.setError("Entre com um endereço de e-mail válido");
            valid = false;
        } else {
            mEmailView.setError(null);
        }

        if (nome_user.isEmpty() || nome_user.length() < 3) {
            mNameView.setError("Entre com um nome válido");
            valid = false;
        } else {
            mNameView.setError(null);
        }

        if (sobrenome_user.isEmpty() || sobrenome_user.length() < 3) {
            mLastNameView.setError("Entre com um sobrenome válido");
            valid = false;
        } else {
            mLastNameView.setError(null);
        }

        if (bitmap == null) {
            Toast.makeText(SignUpUserActivity.this,"Entre com uma foto de perfil",Toast.LENGTH_LONG).show();
            valid = false;
        }else {
            notifierIcon.setImageResource(0);
        }

        if (senha_user.isEmpty() || senha_user.length() < 4) {
            mPasswordView.setError("A senha deve ser maior do que quatro caracteres");
            valid = false;
        } else {
            mPasswordView.setError(null);
        }

        if(confirmar_senha.isEmpty() || senha_user.isEmpty()) {
            mPasswordConfirmView.setError("Preencha todos os campos");
            valid = false;
        }else if (!confirmar_senha.equals(senha_user)){
            mPasswordConfirmView.setError("As senhas não batem");
            valid = false;
        }else {
            mPasswordConfirmView.setError(null);
        }


        return valid;
    }

}