package com.waveofhelp.walp.walp.Fragments.EditProfileOngFragments;

import android.os.AsyncTask;

import com.google.gson.Gson;
import com.waveofhelp.walp.walp.Fragments.EditProfileOngFragments.EditProfileOngFragment;
import com.waveofhelp.walp.walp.Activity.SignUpOngActivity.Address;
import com.waveofhelp.walp.walp.Activity.SignUpOngActivity.JsonRequest;

import java.lang.ref.WeakReference;

/**
 * Created by beta17 on 9/23/17.
 */

public class AddressRequestEditProfileOng extends AsyncTask<Void, Void, Address> {
    private WeakReference<EditProfileOngFragment> fragment;

    public AddressRequestEditProfileOng(EditProfileOngFragment fragment ){
        this.fragment = new WeakReference<>( fragment );
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        fragment.get().lockFields( true );
    }

    @Override
    protected Address doInBackground(Void... voids) {

        try{
            //String jsonString = JsonRequest.request( fragment.get().getUriRequest() );
            //Gson gson = new Gson();

            //return gson.fromJson(jsonString, Address.class);
        }
        catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Address address) {
        super.onPostExecute(address);

        if( fragment.get() != null ){
            fragment.get().lockFields( false );

            if( address != null ){
                fragment.get().setAddressFields(address);
            }
        }
    }
}
