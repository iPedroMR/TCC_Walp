package com.waveofhelp.walp.walp.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.NetworkControllers.CustomVolleyRequest;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class StatusOngDonationActivity extends AppCompatActivity implements View.OnClickListener {

    TextView nameOng, nameUser, nameDonation, quantity, startDate, finishDate, status;
    CircleImageView imageUser, imageOng;
    Button buttonDonationConfirm, buttonDonationCancel;
    LinearLayout linearLayoutFinishDate;

    private String idDonation;
    private RequestQueue queue;
    private String textFinishDate, textStartDate, textNameUser, textImageUser;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_donation);

        nameOng = findViewById(R.id.text_name_ong);
        nameUser = findViewById(R.id.text_name_user);
        imageUser = findViewById(R.id.image_user);
        imageOng = findViewById(R.id.image_ong);
        nameDonation = findViewById(R.id.text_name_donation);
        quantity = findViewById(R.id.text_quantity_donation);
        startDate = findViewById(R.id.text_date_start);
        finishDate = findViewById(R.id.text_date_finish);
        status = findViewById(R.id.text_status_donation);
        buttonDonationConfirm = findViewById(R.id.button_donation_confirm);
        buttonDonationCancel = findViewById(R.id.button_donation_cancel);
        linearLayoutFinishDate = findViewById(R.id.linear_layout_date_finish);


        Intent intentThatStartedThisActivity = getIntent();

        if (intentThatStartedThisActivity.hasExtra("ongName")) {
            nameOng.setText(intentThatStartedThisActivity.getStringExtra("ongName"));
        }

        if (intentThatStartedThisActivity.hasExtra("donationName")) {
            nameDonation.setText(intentThatStartedThisActivity.getStringExtra("donationName"));
        }

        if (intentThatStartedThisActivity.hasExtra("idDonation")) {
            idDonation = intentThatStartedThisActivity.getStringExtra("idDonation");
            queue = Volley.newRequestQueue(this);
            getData();
        }

        if (intentThatStartedThisActivity.hasExtra("image")) {
            ImageLoader imageLoader = CustomVolleyRequest.getInstance(this).getImageLoader();
            imageLoader.get(intentThatStartedThisActivity.getStringExtra("image"), ImageLoader.getImageListener(imageOng, R.drawable.image, android.R.drawable.ic_dialog_alert));
            Bitmap bitmap = ((BitmapDrawable) imageOng.getDrawable()).getBitmap();
            imageOng.setImageBitmap(bitmap);
        }

        if (intentThatStartedThisActivity.hasExtra("quantity")) {
            quantity.setText(intentThatStartedThisActivity.getStringExtra("quantity"));
        }

        if (intentThatStartedThisActivity.hasExtra("status")) {

            String finalTextStatus;

            switch (intentThatStartedThisActivity.getStringExtra("status")) {
                case "00":
                    finalTextStatus = "Doação pendente";
                    break;
                case "01":
                    finalTextStatus = "Você sinalizou como concluída";
                    buttonDonationCancel.setVisibility(View.GONE);
                    buttonDonationConfirm.setVisibility(View.GONE);
                    break;
                case "10":
                    finalTextStatus = "O usuário sinalizou como concluída";
                    buttonDonationCancel.setVisibility(View.GONE);
                    buttonDonationConfirm.setVisibility(View.VISIBLE);
                    break;
                case "11":
                    finalTextStatus = "Doação concluída";
                    buttonDonationCancel.setVisibility(View.GONE);
                    buttonDonationConfirm.setVisibility(View.GONE);
                    break;
                case "22":
                    finalTextStatus = "Doação cancelada";
                    buttonDonationCancel.setVisibility(View.GONE);
                    buttonDonationConfirm.setVisibility(View.GONE);
                    break;
                case "20":
                    finalTextStatus = "O usuário cancelou a doação";
                    String confirmDenied = "Confirmar cancelamento";
                    buttonDonationCancel.setVisibility(View.VISIBLE);
                    buttonDonationCancel.setText(confirmDenied);
                    buttonDonationConfirm.setVisibility(View.GONE);
                    break;
                case "02":
                    finalTextStatus = "Você cancelou a doação";
                    buttonDonationCancel.setVisibility(View.GONE);
                    buttonDonationConfirm.setVisibility(View.GONE);
                    break;
                default:
                    finalTextStatus = "Indefinido";
                    break;
            }
            status.setText(finalTextStatus);
        }

        buttonDonationConfirm.setOnClickListener(this);
        buttonDonationCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonDonationConfirm) {
            //Creating an alert dialog to confirm logout
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("A doação foi efetuada ?");
            alertDialogBuilder.setPositiveButton("Sim",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {

                            String urlSendData = Constants.URL_SEND_STATUS_ONG;

                            StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSendData,
                                    new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            //If we are getting success from server
                                            if (response.equalsIgnoreCase(Constants.Success)) {
                                                onBackPressed();
                                                Toast.makeText(StatusOngDonationActivity.this, "Alteração feita com sucesso!", Toast.LENGTH_LONG).show();
                                                finish();
                                            } else {
                                                onBackPressed();
                                                Toast.makeText(StatusOngDonationActivity.this, "Alteração feita com sucesso!", Toast.LENGTH_LONG).show();
                                                finish();
                                            }
                                        }
                                    },
                                    new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            //Dismissing the progress dialog
                                            Toast.makeText(getApplicationContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                                        }
                                    }) {

                                @Override
                                protected Map<String, String> getParams() throws AuthFailureError {


                                    Map<String, String> params = new HashMap<String, String>();

                                    params.put("id_doacao", idDonation);
                                    params.put("situacao", "1");

                                    return params;

                                }

                            };

                            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                                    10000,
                                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                            RequestQueue requestQueue = Volley.newRequestQueue(StatusOngDonationActivity.this);
                            requestQueue.add(stringRequest);

                        }
                    });

            alertDialogBuilder.setNegativeButton("Não",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });

            //Showing the alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }

        if (v == buttonDonationCancel) {
            //Creating an alert dialog to confirm logout
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("Tem certeza que deseja cancelar a doação?");
            alertDialogBuilder.setPositiveButton("Sim",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {

                            String urlSendData = Constants.URL_SEND_STATUS_ONG;

                            StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSendData,
                                    new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            //If we are getting success from server
                                            if (response.equalsIgnoreCase(Constants.Success)) {
                                                onBackPressed();
                                                Toast.makeText(StatusOngDonationActivity.this, "Alteração feita com sucesso!", Toast.LENGTH_LONG).show();
                                                finish();
                                            } else {
                                                onBackPressed();
                                                Toast.makeText(StatusOngDonationActivity.this, "Alteração feita com sucesso!", Toast.LENGTH_LONG).show();
                                                finish();
                                            }
                                        }
                                    },
                                    new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            //Dismissing the progress dialog
                                            Toast.makeText(getApplicationContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                                        }
                                    }) {

                                @Override
                                protected Map<String, String> getParams() throws AuthFailureError {


                                    Map<String, String> params = new HashMap<String, String>();

                                    params.put("id_doacao", idDonation);
                                    params.put("situacao", "2");

                                    return params;

                                }

                            };

                            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                                    10000,
                                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                            RequestQueue requestQueue = Volley.newRequestQueue(StatusOngDonationActivity.this);
                            requestQueue.add(stringRequest);

                        }
                    });

            alertDialogBuilder.setNegativeButton("Não",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });

            //Showing the alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }

    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getApplicationContext()).getRequestQueue();

        //Volley's inbuilt class to make Json array request
        String url = Constants.URL_FEED_STATUS_ONG;
        return new JsonArrayRequest(Request.Method.GET, url + "?id_doacao=" + idDonation, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
                Toast.makeText(StatusOngDonationActivity.this,error.toString(),Toast.LENGTH_LONG).show();
            }

        }) {
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    String jsonString = new String(response.data,
                            HttpHeaderParser
                                    .parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString),
                            HttpHeaderParser
                                    .parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                } catch (JSONException je) {
                    return Response.error(new ParseError(je));
                }
            }
        };
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {
            JSONObject json;
            try {

                //Getting json
                json = array.getJSONObject(i);

                //Adding data to the ONG object
                textStartDate = (json.getString("DATA_DOACAO"));
                textFinishDate = (json.getString("DATA_ENTREGA"));
                textImageUser = (json.getString("LOGO_ONG"));
                textNameUser = (json.getString("NOME_ONG"));

                setData();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void setData() {
        ImageLoader imageLoader = CustomVolleyRequest.getInstance(this).getImageLoader();
        imageLoader.get(textImageUser, ImageLoader.getImageListener(imageUser, R.drawable.image, R.drawable.ic_more_horiz_black_24dp));
        Bitmap bitmap = ((BitmapDrawable) imageUser.getDrawable()).getBitmap();

        if (!textFinishDate.equals("0")) {
            finishDate.setText(textFinishDate);
        } else {
            linearLayoutFinishDate.setVisibility(View.GONE);
        }
        startDate.setText(textStartDate);
        nameUser.setText(textNameUser);

        imageUser.setImageBitmap(bitmap);
    }

}
