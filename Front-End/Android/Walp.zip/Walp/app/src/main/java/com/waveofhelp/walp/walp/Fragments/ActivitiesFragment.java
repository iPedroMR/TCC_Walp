package com.waveofhelp.walp.walp.Fragments;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.waveofhelp.walp.walp.Objects.Donation;
import com.waveofhelp.walp.walp.Objects.NewsFeeds;
import com.waveofhelp.walp.walp.R;
import com.waveofhelp.walp.walp.Adapters.RVAAdapter;
import com.waveofhelp.walp.walp.Adapters.RVDAdapter;

import java.util.ArrayList;
import java.util.List;

public class ActivitiesFragment extends Fragment {

    private List<NewsFeeds> newsFeedsList;
    private List<Donation> donationList = new ArrayList<>();
    private RecyclerView rva;
    private RecyclerView rvd;


    public ActivitiesFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_activities, container, false);
        RecyclerView rv = rootView.findViewById(R.id.rva);
        RecyclerView rvd = rootView.findViewById(R.id.rvd);

        rv.setHasFixedSize(true);
        rvd.setHasFixedSize(true);


        LinearLayoutManager llm = new LinearLayoutManager(getActivity().getApplicationContext());
        llm.setOrientation(OrientationHelper.HORIZONTAL);
        rv.setLayoutManager(llm);

        LinearLayoutManager lld = new LinearLayoutManager(getActivity().getApplicationContext());
        lld.setOrientation(OrientationHelper.HORIZONTAL);
        rvd.setLayoutManager(lld);

        RVAAdapter adapter = new RVAAdapter(newsFeedsList, getContext());
        rv.setAdapter(adapter);

        RVDAdapter adapter1 = new RVDAdapter(donationList, getContext());
        rvd.setAdapter(adapter1);

        return rootView;
    }
}
