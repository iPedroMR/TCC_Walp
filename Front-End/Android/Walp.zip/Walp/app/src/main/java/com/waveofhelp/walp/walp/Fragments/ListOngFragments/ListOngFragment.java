package com.waveofhelp.walp.walp.Fragments.ListOngFragments;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationServices;
import com.waveofhelp.walp.walp.*;
import com.waveofhelp.walp.walp.Adapters.RVAdapter;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.Objects.NewsFeeds;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Pedro on 27/04/2017.
 */

public class ListOngFragment extends Fragment implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private static final int MY_PERMISSION_REQUEST_CODE = 0;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 0;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;
    private String stringLatitude, stringLongitude;
    private List<NewsFeeds> feedsList;
    protected SwipeRefreshLayout mSwipeRefreshLayout;
    double latitude, longitude;
    SearchView sv;
    RVAdapter adapter;
    RequestQueue queue;
    private RelativeLayout progressBar;

    // CONNECTION_TIMEOUT and READ_TIMEOUT are in milliseconds
    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;

    public LinearLayout connectionViewFailed;
    public RecyclerView rv;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    public ListOngFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(com.waveofhelp.walp.walp.R.layout.fragment_list_ong, container, false);

        rv = rootView.findViewById(R.id.rv);
        rv.setHasFixedSize(true);

        progressBar = rootView.findViewById(R.id.progressBar);

        connectionViewFailed = rootView.findViewById(R.id.connection_failed);

        if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //Run-time request permission
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSION_REQUEST_CODE);
        } else {
            if (checkPlayServices() && checkInternet()) {
                callConection();
            }
        }

        connectionViewFailed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkInternet()) {
                    callConection();
                } else {
                    Toast.makeText(getContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                }
            }
        });

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(llm);

        //Initializing our list
        feedsList = new ArrayList<>();
        queue = Volley.newRequestQueue(getContext());

        //Calling method to get data to fetch data
        //getData();

        //initializing our adapter
        adapter = new RVAdapter(feedsList, getContext());

        rv.addOnScrollListener(rVOnScrollListener);

        //Adding adapter to recyclerview
        rv.setAdapter(adapter);

        //SEARCH VIEW
        sv = rootView.findViewById(R.id.search_view_widget);

        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                //FILTER AS YOU TYPE
                new AsyncFetch(query).execute();
                return false;
            }
        });

        //SWIPE LAYOUT

        mSwipeRefreshLayout = rootView.findViewById(R.id.srl_swipe);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mSwipeRefreshLayout.setRefreshing(true);
                //AÇÃO SWIPE REFRESH LAYOUT
                if (checkInternet()) {
                    callConection();
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
        return rootView;
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getContext());
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode,
                        getActivity(), PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Toast.makeText(getContext(), "This device is not supported", Toast.LENGTH_LONG).show();
            }
            return false;
        }
        return true;
    }

    private synchronized void callConection() {
        progressBar.setVisibility(View.VISIBLE);
        mGoogleApiClient = new GoogleApiClient.Builder(getContext())
                .addOnConnectionFailedListener(this)
                .addConnectionCallbacks(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

    //LISTENER
    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if (mLastLocation != null) {
            latitude = mLastLocation.getLatitude();
            longitude = mLastLocation.getLongitude();

            //Clear a old list
            feedsList.clear();
            getData();
        } else {
            mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        checkPlayServices();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation = location;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (checkPlayServices())
                        callConection();
                }
                break;
        }
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {
        this.requestCount = requestCount;

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getContext()).getRequestQueue();

        //Converting Bitmap to String
        stringLatitude = Double.toString(latitude);
        stringLongitude = Double.toString(longitude);

        //Volley's inbuilt class to make Json array request
        String url = Constants.URL_FEED;
        return new JsonArrayRequest(url + "?lat_user=" + stringLatitude + "&long_user=" + stringLongitude, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {

                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        });
    }

    //This method will get data from the web api
    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {

            progressBar.setVisibility(View.GONE);
            //Creating the superhero object
            NewsFeeds newsFeeds = new NewsFeeds();
            JSONObject json;
            try {
                //Getting json
                json = array.getJSONObject(i);

                //Adding data to the ONG object
                newsFeeds.setID_ONG(json.getString("ID_ONG"));
                newsFeeds.setNOME_ONG(json.getString("NOME_ONG"));
                newsFeeds.setTIPO_ONG(json.getString("TIPO_ONG"));
                newsFeeds.setIMAGEM_ONG(json.getString("LOGO_ONG"));
                newsFeeds.setDISTANCIA_ONG(json.getString("DISTANCIA"));

            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Adding the ONG object to the list
            feedsList.add(newsFeeds);
        }
        //Notifying the adapter that data has been added or changed
        adapter.notifyDataSetChanged();
    }

    //This method would check that the recyclerview scroll has reached the bottom or not
    private boolean isLastItemDisplaying(RecyclerView recyclerView) {
        if (recyclerView.getAdapter().getItemCount() != 0) {
            int lastVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastCompletelyVisibleItemPosition();
            if (lastVisibleItemPosition != RecyclerView.NO_POSITION && lastVisibleItemPosition == recyclerView.getAdapter().getItemCount() - 1)
                return true;
        }
        return false;
    }

    public boolean checkInternet() {
        boolean connected = false;
        ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                // connected to wifi
                rv.setVisibility(View.VISIBLE);
                connectionViewFailed.setVisibility(View.INVISIBLE);
                connected = true;
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                rv.setVisibility(View.VISIBLE);
                connectionViewFailed.setVisibility(View.INVISIBLE);
                connected = true;
            }
        } else {
            // not connected to the internet
            rv.setVisibility(View.GONE);
            connectionViewFailed.setVisibility(View.VISIBLE);
            connected = false;
        }
        return connected;
    }

    private RecyclerView.OnScrollListener rVOnScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView,
                                         int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            if (isLastItemDisplaying(recyclerView)) {
                //Calling the method getdata again
                //getData();
            }
        }
    };

    // Create class AsyncFetch
    private class AsyncFetch extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url = null;
        String searchQuery;

        public AsyncFetch(String searchQuery) {
            this.searchQuery = searchQuery;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {
            try {

                // Enter URL address where your php file resides
                url = new URL("https://walpweb.com.br/PHP/selectSearch.php");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return e.toString();
            }
            try {

                // Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(READ_TIMEOUT);
                conn.setConnectTimeout(CONNECTION_TIMEOUT);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput to true as we send and recieve data
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // add parameter to our above url
                Uri.Builder builder = new Uri.Builder().appendQueryParameter("pesquisa", searchQuery);
                builder.appendQueryParameter("long_user", stringLongitude);
                builder.appendQueryParameter("lat_user",stringLatitude);
                String query = builder.build().getEncodedQuery();

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return e1.toString();
            }

            try {

                int response_code = conn.getResponseCode();

                // Check if successful connection made
                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }

                    // Pass data to onPostExecute method
                    return (result.toString());

                } else {
                    return ("Erro de conexão");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return e.toString();
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            //this method will be running on UI thread
            List<NewsFeeds> data = new ArrayList<>();

            if (result.equals("no rows")) {
                Toast.makeText(getContext(), "Sem resultados", Toast.LENGTH_LONG).show();
            } else {

                try {

                    JSONArray jArray = new JSONArray(result);

                    // Extract data from json and store into ArrayList as class objects
                    for (int i = 0; i < jArray.length(); i++) {
                        JSONObject json_data = jArray.getJSONObject(i);
                        NewsFeeds newsFeeds = new NewsFeeds();

                        newsFeeds.setID_ONG(json_data.getString("ID_ONG"));
                        newsFeeds.setNOME_ONG(json_data.getString("NOME_ONG"));
                        newsFeeds.setTIPO_ONG(json_data.getString("TIPO_ONG"));
                        newsFeeds.setIMAGEM_ONG(json_data.getString("LOGO_ONG"));
                        newsFeeds.setDISTANCIA_ONG(json_data.getString("DISTANCIA"));

                        data.add(newsFeeds);
                    }

                    // Setup and Handover data to recyclerview
                    adapter = new RVAdapter(data, getContext());
                    rv.setAdapter(adapter);
                    rv.setLayoutManager(new LinearLayoutManager(getContext()));

                } catch (JSONException e) {
                    // You to understand what actually error is and handle it appropriately
                }

            }

        }
    }

}