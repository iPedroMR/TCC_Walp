package com.waveofhelp.walp.walp;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;

import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * Created by beta17 on 23/05/18.
 */

public class BootBroadcast extends BroadcastReceiver {

    private GPS_Service gps_service;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onReceive(Context ctx, Intent intent) {

        gps_service = new GPS_Service(ctx);
        Intent i = new Intent(ctx, gps_service.getClass());

        ComponentName serviceComponent = new ComponentName(getApplicationContext(), GPS_Service.class);
        JobInfo.Builder builder = new JobInfo.Builder(0, serviceComponent);
        builder.setMinimumLatency(2 * 1000000000); // wait at least
        builder.setOverrideDeadline(3 * 1000); // maximum delay
        JobScheduler jobScheduler = ctx.getSystemService(JobScheduler.class);
        jobScheduler.schedule(builder.build());
        ctx.startService(i);
    }
}

