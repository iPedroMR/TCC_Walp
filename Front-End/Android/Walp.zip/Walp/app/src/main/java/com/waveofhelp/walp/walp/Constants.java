package com.waveofhelp.walp.walp;

import com.google.android.gms.maps.model.LatLng;

import java.util.HashMap;

/**
 * Created by Pedro on 27/05/2017.
 */

public class Constants {

    private static  final  String ROOT_URL = "https://www.walpweb.com.br/PHP/";
    public static final String URL_REGISTER = ROOT_URL+"insertUser.php";
    public static final String URL_REGISTER_ONG = ROOT_URL+"insertOng.php";
    public static final String URL_LOGIN = ROOT_URL+"login.php";
    public static final String URL_FEED = ROOT_URL+"selectListaUsers.php";
    public static final String URL_FEED_DONATED = ROOT_URL+"selectAtividadeUser.php";
    public static final String URL_FEED_DONATED_ONG = ROOT_URL+"selectAtividadeOng.php";
    public static final String URL_FEED_NEED = ROOT_URL+"selectNece.php";
    public static final String URL_DONATION_USER = ROOT_URL+"selectDoacao.php";
    public static final String URL_UPDATE_ONG = ROOT_URL+"UpdateONG.php";
    public static final String URL_UPDATE_NEED = ROOT_URL+"UpdateNece.php";
    public static final String URL_UPDATE_USER = ROOT_URL+"UpdateUser.php";
    public static final String URL_PERFIL_ONG = ROOT_URL+"selectPerfilONG.php";
    public static final String URL_PERFIL_USER = ROOT_URL+"selectPerfilUser.php";
    public static final String URL_DELETE_USER = ROOT_URL+"deleteUser.php";
    public static final String URL_DELETE_ONG = ROOT_URL+"deleteOng.php";
    public static final String URL_DELETE_NEED = ROOT_URL+"deleteNece.php";
    public static final String URL_INSERT_NEED = ROOT_URL+"insertNecessidade.php";
    public static final String URL_INSERT_DONATION = ROOT_URL+"insertDoacao.php";
    public static final String URL_SEND_STATUS_USER = ROOT_URL+"UpdateStatusUser.php";
    public static final String URL_SEND_STATUS_ONG = ROOT_URL+"UpdateStatusOng.php";
    public static final String URL_FEED_STATUS = ROOT_URL+"selectPerfilDoacao.php";
    public static final String URL_FEED_STATUS_ONG = ROOT_URL+"selectPerfilDoador.php";
    public static final String URL_LATLONG_ONG = ROOT_URL+"selectLatLong.php";


    public static  String KEY_PASSWORD = "password";

    //If server response is equal to this that means login is successful
    public static final String Success = "true";

    //Tentativas de login do usuário
    public static  final String LOGIN_ATTEMPTS = "false";

    //Keys for Sharedpreferences
    //This would be the name of our shared preferences
    public static final String SHARED_PREF_NAME = "walp_app_shared";

    //This would be used to store the email of current logged in user
    public static final String EMAIL_SHARED_PREF = "email";

    //We will use this to store the boolean in sharedpreference to track user is loggedin or not
    public static final String LOGGEDIN_SHARED_PREF = "loggcedin";

    public static  final String ID_SHARED_PREF = "62";

    //Identificar qual o tipo de usuário; 0 = nenhum; 1 = Doador; 2 = NewsFeeds;
    public static  final String USER_TYPE_SHARED_PREF = "2";

    public static final String FRIENDLY_MSG_LENGTH = "friendly_msg_length";

    //JSON TAGS
    public static final String TAG_ID = "ID_ONG";
    public static final String TAG_IMAGE_URL = "LOGO_ONG";
    public static final String TAG_NAME = "NOME_ONG";
    public static final String TAG_PUBLISHER = "TIPO_ONG";
    public static final String TAG_DISTANCE = "DISTANCIA";
}
