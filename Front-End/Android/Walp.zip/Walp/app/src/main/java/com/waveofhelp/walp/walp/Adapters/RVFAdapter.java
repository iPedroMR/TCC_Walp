package com.waveofhelp.walp.walp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.waveofhelp.walp.walp.Activity.ProfileOngActivity;
import com.waveofhelp.walp.walp.Objects.Causes;
import com.waveofhelp.walp.walp.R;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by beta17 on 19/02/18.
 */

public class RVFAdapter extends RecyclerView.Adapter<RVFAdapter.CauseViewHolder> {

    private Context context;

    //List of all ONGS
    public List<Causes> newsCauseList;
    private LayoutInflater inflater;
    private Causes causes;

    public RVFAdapter(List<Causes> newsCauseList, Context context) {
        this.newsCauseList = newsCauseList;
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public CauseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View rootView = inflater.inflate(R.layout.card_cause_find, parent, false);
        return new CauseViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(final CauseViewHolder causeViewHolder, final int position) {
        //Getting the particular item from the list
        causes = newsCauseList.get(position);
    }

    @Override
    public int getItemCount() {
        return newsCauseList.size();
    }

    public final class CauseViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout relativeLayoutCause = itemView.findViewById(R.id.rl_card);
        ImageView causeImage = itemView.findViewById(R.id.image_cause);
        TextView causeText = itemView.findViewById(R.id.text_title);
        TextView causeDescription = itemView.findViewById(R.id.text_description);

        private CauseViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();

            relativeLayoutCause.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {

                }
            });
        }

    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }
}
