package com.waveofhelp.walp.walp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.ImageLoader;
import com.waveofhelp.walp.walp.Activity.StatusDonationActivity;
import com.waveofhelp.walp.walp.Activity.StatusOngDonationActivity;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.NetworkControllers.CustomVolleyRequest;
import com.waveofhelp.walp.walp.Objects.DonationList;
import com.waveofhelp.walp.walp.R;

import java.io.ByteArrayOutputStream;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by beta17 on 22/10/17.
 */

public class RVDLAdapter extends RecyclerView.Adapter<RVDLAdapter.DonationListViewHolder> {
    private Context context;

    public List<DonationList> donationLists;
    private LayoutInflater inflater;
    private DonationList donation;
    private String urlPhoto;
    private String userType;

    public RVDLAdapter(List<DonationList> donationLists, Context context) {
        this.donationLists = donationLists;
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public DonationListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View rootView = inflater.inflate(R.layout.card_management, parent, false);
        return new DonationListViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(final DonationListViewHolder donationListViewHolder, final int position) {
        //Getting the particular item from the list
        donation = donationLists.get(position);

        donationListViewHolder.urlPhoto = donation.getIMAGEM_ONG();

        //Loading image from url
        ImageLoader imageLoader = CustomVolleyRequest.getInstance(context).getImageLoader();
        imageLoader.get(donation.getIMAGEM_ONG(), ImageLoader.getImageListener(donationListViewHolder.ongPhoto, R.drawable.image, android.R.drawable.ic_dialog_alert));
        Bitmap bitmap = ((BitmapDrawable) donationListViewHolder.ongPhoto.getDrawable()).getBitmap();

        //Showing data on the views
        donationListViewHolder.ongName.setText(donation.getNAME_ONG());
        donationListViewHolder.donationName.setText(donation.getNAME_DONATION());
        donationListViewHolder.donationQuantity.setText(donation.getQUANTITY_DONATION());
        donationListViewHolder.ongPhoto.setImageBitmap(bitmap);
        donationListViewHolder.textStatusDonation = donation.getSTATUS_DONATION();
        donationListViewHolder.idDonation = donation.getID_DONATION();

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        donationListViewHolder.userType = sharedPreferences.getString(Constants.USER_TYPE_SHARED_PREF, "0");

        String finalTextStatus = "Indefinido";

        if(donationListViewHolder.userType.equals("1")) {

            switch (donationListViewHolder.textStatusDonation) {
                case "00":
                    finalTextStatus = "Doação pendente";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_truck_delivery);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.yelow_waiting);
                    break;
                case "01":
                    finalTextStatus = "A ONG sinalizou como concluída";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_more_horiz_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.rgb(48, 48, 48));
                    donationListViewHolder.statusColor.setImageResource(R.color.windowBackground);
                    break;
                case "10":
                    finalTextStatus = "Você sinalizou como concluída";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_check_white_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.green_check);
                    break;
                case "11":
                    finalTextStatus = "Doação concluída";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_check_white_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.green_check);
                    break;
                case "22":
                    finalTextStatus = "Doação cancelada";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.red_denied);
                    break;
                case "20":
                    finalTextStatus = "Você cancelou a doação";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.red_denied);
                    break;
                case "02":
                    finalTextStatus = "A ONG cancelou a doação";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.red_denied);
                    break;
                default:
                    finalTextStatus = "Indefinido";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.colorPrimary);
                    break;
            }

        }else if(donationListViewHolder.userType.equals("2")){

            switch (donationListViewHolder.textStatusDonation) {
                case "00":
                    finalTextStatus = "Doação pendente";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_call_received_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.yelow_waiting);
                    break;
                case "01":
                    finalTextStatus = "Você sinalizou como concluída";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_check_white_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.green_check);
                    break;
                case "10":
                    finalTextStatus = "O usuário sinalizou como concluída";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_more_horiz_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.rgb(48, 48, 48));
                    donationListViewHolder.statusColor.setImageResource(R.color.windowBackground);
                    break;
                case "11":
                    finalTextStatus = "Doação concluída";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_check_white_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.green_check);
                    break;
                case "22":
                    finalTextStatus = "Doação cancelada";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.red_denied);
                    break;
                case "20":
                    finalTextStatus = "O usuário cancelou a doação";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.red_denied);
                    break;
                case "02":
                    finalTextStatus = "Você cancelou a doação";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.red_denied);
                    break;
                default:
                    finalTextStatus = "Indefinido";
                    donationListViewHolder.statusIcon.setImageResource(R.drawable.ic_close_black_24dp);
                    donationListViewHolder.statusIcon.setColorFilter(Color.argb(255, 255, 255, 255));
                    donationListViewHolder.statusColor.setImageResource(R.color.colorPrimary);
                    break;
            }
        }

        donationListViewHolder.statusDonation.setText(finalTextStatus);

    }

    @Override
    public int getItemCount() {
        return donationLists.size();
    }

    public final class DonationListViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        LinearLayout ll_cv;
        TextView ongName;
        TextView statusDonation;
        TextView donationQuantity;
        TextView donationName;
        CircleImageView ongPhoto, statusColor;
        ImageView setStatus, statusIcon;
        String idDonation, textStatusDonation;
        String urlPhoto;
        String userType;

        private DonationListViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cv = itemView.findViewById(R.id.card_view_donations);
            ll_cv = itemView.findViewById(R.id.ll_cv);
            ongName = itemView.findViewById(R.id.ong_name);
            donationName = itemView.findViewById(R.id.donation_name);
            donationQuantity = itemView.findViewById(R.id.donation_quantity);
            statusColor = itemView.findViewById(R.id.status_color);
            statusIcon = itemView.findViewById(R.id.icon_status);
            ongPhoto = itemView.findViewById(R.id.user_photo);
            statusDonation = itemView.findViewById(R.id.donation_status);
            setStatus = itemView.findViewById(R.id.image_set_status);

            ll_cv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {

                    String nameOng = ongName.getText().toString();
                    String nameDonation = donationName.getText().toString();
                    String quantity = donationQuantity.getText().toString();

                    Class destinationActivity = StatusDonationActivity.class;

                    if(userType.equals("1")){
                        destinationActivity = StatusDonationActivity.class;
                    }else if(userType.equals("2")){
                        destinationActivity = StatusOngDonationActivity.class;
                    }

                    Intent startPortfolioActivityIntent = new Intent(context, destinationActivity);
                    startPortfolioActivityIntent.putExtra("ongName", nameOng);
                    startPortfolioActivityIntent.putExtra("donationName", nameDonation);
                    startPortfolioActivityIntent.putExtra("idDonation", idDonation);
                    startPortfolioActivityIntent.putExtra("image", urlPhoto);
                    startPortfolioActivityIntent.putExtra("quantity", quantity);
                    startPortfolioActivityIntent.putExtra("status", textStatusDonation);

                    context.startActivity(startPortfolioActivityIntent);
                }
            });
        }

    }

}

