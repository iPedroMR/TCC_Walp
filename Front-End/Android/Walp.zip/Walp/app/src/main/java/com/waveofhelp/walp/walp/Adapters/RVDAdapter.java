package com.waveofhelp.walp.walp.Adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.waveofhelp.walp.walp.Objects.Donation;
import com.waveofhelp.walp.walp.R;

import java.util.List;

/**
 * Created by Pedro on 27/04/2017.
 */

public class RVDAdapter extends RecyclerView.Adapter<RVDAdapter.OngViewHolder> {

    Context context;


    public final class OngViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        TextView donationName;
        TextView ongName;
        TextView time;
        TextView data;
        TextView status;
        ImageView photoDonation;

        public OngViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cv = itemView.findViewById(R.id.card_view_donations);
            donationName = itemView.findViewById(R.id.name_donation);
            ongName = itemView.findViewById(R.id.ong_name);
            time = itemView.findViewById(R.id.tv_time);
            data =  itemView.findViewById(R.id.donation_data);
            status = itemView.findViewById(R.id.donation_status);
            photoDonation = itemView.findViewById(R.id.donation_photo);
        }
    }

    List<Donation> donationList;

    public RVDAdapter(List<Donation> donationList, Context context) {
        this.donationList = donationList;
        this.context = context;
    }


    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public RVDAdapter.OngViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_donations, parent, false);
        return new RVDAdapter.OngViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final RVDAdapter.OngViewHolder ongViewHolder, final int position) {
        ongViewHolder.photoDonation.setImageResource(donationList.get(position).photoDonation);
        ongViewHolder.donationName.setText(donationList.get(position).name);
        ongViewHolder.ongName.setText(donationList.get(position).nameOng);
        ongViewHolder.data.setText(donationList.get(position).data);
        ongViewHolder.time.setText(donationList.get(position).data);
        ongViewHolder.status.setText(donationList.get(position).status);

        //ongViewHolder.cv.setOnClickListener(new View.OnClickListener(){
        //    public void onClick(View view){
        //        String textName = ongViewHolder.donationName.getText().toString();
        //        String textData = ongViewHolder.data.getText().toString();
        //        String textStatus = ongViewHolder.status.getText().toString();
        //        String textOngName = ongViewHolder.status.getText().toString();
        //        Bitmap imageLogo = ((BitmapDrawable) ongViewHolder.photoDonation.getDrawable()).getBitmap();
        //
        //        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        //        imageLogo.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        //        byte[] byteArray = stream.toByteArray();

        //        Class destinationActivity = ProfileOngActivity.class;
        //        Intent startPortfolioActivityIntent = new Intent (context, destinationActivity);
        //        startPortfolioActivityIntent.putExtra(Intent.EXTRA_REFERRER_NAME, textName);
        //        startPortfolioActivityIntent.putExtra(Intent.EXTRA_TEXT, textData);
        //        startPortfolioActivityIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, textStatus);
        //       startPortfolioActivityIntent.putExtra(Intent.EXTRA_TITLE, textOngName);
        //        startPortfolioActivityIntent.putExtra("Image", byteArray);
        //        context.startActivity(startPortfolioActivityIntent);
        //    }
        //});
    }

    @Override
    public int getItemCount() {
        return donationList.size();
    }

}