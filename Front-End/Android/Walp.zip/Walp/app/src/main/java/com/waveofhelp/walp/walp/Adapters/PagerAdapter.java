package com.waveofhelp.walp.walp.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.waveofhelp.walp.walp.Fragments.DescriptionsFragments.Description1;
import com.waveofhelp.walp.walp.Fragments.DescriptionsFragments.Description2;
import com.waveofhelp.walp.walp.Fragments.DescriptionsFragments.Description3;
import com.waveofhelp.walp.walp.Fragments.DescriptionsFragments.Description4;

/**
 * Created by Pedro on 18/03/2017.
 */

public class PagerAdapter extends FragmentPagerAdapter {

	public PagerAdapter(FragmentManager fm) {
		super(fm);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Fragment getItem(int arg0) {
		// TODO Auto-generated method stub
		switch (arg0) {
			case 0:
				return new Description1();
			case 1:
				return new Description2();
			case 2:
				return new Description3();
			case 3:
				return new Description4();
			default:
				break;
		}
		return null;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 4;
	}

}