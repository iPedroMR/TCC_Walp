package com.waveofhelp.walp.walp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.waveofhelp.walp.walp.Activity.ProfileOngActivity;
import com.waveofhelp.walp.walp.Objects.NewsFeeds;
import com.waveofhelp.walp.walp.R;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Created by Pedro on 27/04/2017.
 */

public class RVAAdapter extends RecyclerView.Adapter<RVAAdapter.OngViewHolder>{

    Context context;


    public final class OngViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        TextView ongName;
        ImageView categoryOng;
        ImageView ongPhoto;

        public OngViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cv = itemView.findViewById(R.id.card_view_activities);
            ongName = itemView.findViewById(R.id.ong_name);
            ongPhoto = itemView.findViewById(R.id.ong_favorite_circle);
            categoryOng = itemView.findViewById(R.id.category_ong);
        }
    }

    List<NewsFeeds> newsFeedsList;
    public RVAAdapter(List<NewsFeeds> newsFeedsList, Context context){
        this.newsFeedsList = newsFeedsList; this.context = context;
    }



    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public OngViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_activities, parent, false);
        return new OngViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final OngViewHolder ongViewHolder, final int position) {
        //ongViewHolder.ongPhoto.setImageResource(newsFeedsList.get(position).getPhoto());
        //ongViewHolder.categoryOng.setImageResource(newsFeedsList.get(position).getCategory());
        //ongViewHolder.ongName.setText(newsFeedsList.get(position).getFeedName());
        //final String ongDistance = newsFeedsList.get(position).getDistance();

        ongViewHolder.cv.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                String textName = ongViewHolder.ongName.getText().toString();
                //String textDistance = ongDistance;
                Bitmap imageLogo = ((BitmapDrawable) ongViewHolder.ongPhoto.getDrawable()).getBitmap();

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                imageLogo.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] byteArray = stream.toByteArray();

                Class destinationActivity = ProfileOngActivity.class;
                Intent startPortfolioActivityIntent = new Intent (context, destinationActivity);
                startPortfolioActivityIntent.putExtra(Intent.EXTRA_REFERRER_NAME, textName);
                //startPortfolioActivityIntent.putExtra(Intent.EXTRA_TEXT, textDistance);
                startPortfolioActivityIntent.putExtra("Image", byteArray);
                context.startActivity(startPortfolioActivityIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return newsFeedsList.size();
    }

}