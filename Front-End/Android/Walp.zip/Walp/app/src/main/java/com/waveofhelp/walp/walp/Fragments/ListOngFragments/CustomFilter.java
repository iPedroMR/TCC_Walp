package com.waveofhelp.walp.walp.Fragments.ListOngFragments;

import android.widget.Filter;

import com.waveofhelp.walp.walp.Adapters.RVAdapter;
import com.waveofhelp.walp.walp.Objects.NewsFeeds;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Pedro on 11/07/2017.
 */

public class CustomFilter extends Filter {

    final RVAdapter adapter;
    private List<NewsFeeds> newsFeedsList;

    public CustomFilter(List<NewsFeeds> filterList, RVAdapter adapter)
    {
        this.adapter=adapter;
        this.newsFeedsList =filterList;
    }
    //FILTERING OCURS
    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results=new FilterResults();
        //CHECK CONSTRAINT VALIDITY
        if(constraint != null && constraint.length() > 0)
        {
            //CHANGE TO UPPER
            constraint=constraint.toString().toUpperCase();
            //STORE OUR FILTERED PLAYERS
            List<NewsFeeds> filteredNewsFeedses =new ArrayList<NewsFeeds>(){
            };
            for (int i = 0; i< newsFeedsList.size(); i++)
            {
                //CHECK
                if(newsFeedsList.get(i).getNOME_ONG().toUpperCase().contains(constraint))
                {
                    //ADD PLAYER TO FILTERED PLAYERS
                    filteredNewsFeedses.add(newsFeedsList.get(i));
                }
            }
            results.count= filteredNewsFeedses.size();
            results.values= filteredNewsFeedses;
        }else
        {
            results.count= newsFeedsList.size();
            results.values= newsFeedsList;
        }
        return results;
    }
    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        adapter.newsFeedsList = (List<NewsFeeds>) results.values;
        //REFRESH
        adapter.notifyDataSetChanged();
    }
}