package com.waveofhelp.walp.walp.Activity;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.waveofhelp.walp.walp.Fragments.ListDonatedFragment;
import com.waveofhelp.walp.walp.Fragments.ListDonationFragment;
import com.waveofhelp.walp.walp.R;


public class ThankActivity extends AppCompatActivity implements View.OnClickListener {

    Button homeButton, donationButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank);

        homeButton = findViewById(R.id.home_button);
        donationButton = findViewById(R.id.donation_button);

        homeButton.setOnClickListener(this);
        donationButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == homeButton) {
            Intent intent = new Intent(this, MainUserActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } else if (v == donationButton) {
            Intent intent = new Intent (ThankActivity.this, MainUserActivity.class);
            intent.putExtra("EXTRA", "openFragment");
            startActivity(intent);
        }

    }
}
