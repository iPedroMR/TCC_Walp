package com.waveofhelp.walp.walp.Fragments.ProfileOngFragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.waveofhelp.walp.walp.R;

public class AboutFragment extends Fragment {

    TextView tvEmail, tvTelefone, tvSite, tvSobre, tvRua, tvComplemento, tvCidade, tvEstado,tvBairro,tvNumero, tvTime, tvWeekend;

    CardView cvAbout,cvAddress, cvContact, cvTime;

    LinearLayout llRua, llComplemento, llNumero, llBairro, llCidade, llEstado;

    LinearLayout llEmail, llSite, llPhone;


    public AboutFragment(){
        //Required empty public constructor
    }

    //Overriden method onCreateView
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_about, container, false);
        tvEmail = rootView.findViewById(R.id.tv_email_fragment_about);
        tvTelefone = rootView.findViewById(R.id.tv_ong_phone_number_fragment_about);
        tvSite = rootView.findViewById(R.id.tv_site_fragment_about);
        tvSobre = rootView.findViewById(R.id.tv_about_fragment_about);
        tvRua = rootView.findViewById(R.id.tv_rua_fragment_about);
        tvComplemento = rootView.findViewById(R.id.tv_complemento_fragment_about);
        tvCidade = rootView.findViewById(R.id.tv_cidade_fragment_about);
        tvEstado = rootView.findViewById(R.id.tv_estado_fragment_about);
        tvTime = rootView.findViewById(R.id.tv_time);
        tvBairro = rootView.findViewById(R.id.tv_bairro_fragment_about);
        tvNumero = rootView.findViewById(R.id.tv_numero_fragment_about);
        tvWeekend = rootView.findViewById(R.id.tv_weekend);


        llRua = rootView.findViewById(R.id.ll_rua);
        llComplemento = rootView.findViewById(R.id.ll_complemento);
        llNumero = rootView.findViewById(R.id.ll_numero);
        llBairro = rootView.findViewById(R.id.ll_bairro);
        llCidade = rootView.findViewById(R.id.ll_cidade);
        llEstado = rootView.findViewById(R.id.ll_estado);

        llEmail = rootView.findViewById(R.id.ll_email);
        llSite = rootView.findViewById(R.id.ll_site);
        llPhone = rootView.findViewById(R.id.ll_phone);

        cvAbout = rootView.findViewById(R.id.cv_about);
        cvAddress = rootView.findViewById(R.id.cv_address);
        cvContact = rootView.findViewById(R.id.cv_contact_fragment_about);
        cvTime = rootView.findViewById(R.id.cv_time);

        Bundle bundle = this.getArguments();
        if (bundle != null) {
            //Getting data from ProfileOngActivity

            if(!bundle.getString("sobre").equals("")){
                cvAbout.setVisibility(View.VISIBLE);
                tvSobre.setText(bundle.getString("sobre"));
            }else{
                cvAbout.setVisibility(View.GONE);
            }

            if(!bundle.getString("telefone").equals("")){
                cvContact.setVisibility(View.VISIBLE);
                llPhone.setVisibility(View.VISIBLE);
                tvTelefone.setText(bundle.getString("telefone"));
            }else{
                llPhone.setVisibility(View.GONE);
            }
            if(!bundle.getString("email").equals("")){
                cvContact.setVisibility(View.VISIBLE);
                llEmail.setVisibility(View.VISIBLE);
                tvEmail.setText(bundle.getString("email"));
            }else{
                llEmail.setVisibility(View.GONE);
            }
            if(!bundle.getString("site").equals("")){
                cvContact.setVisibility(View.VISIBLE);
                llSite.setVisibility(View.VISIBLE);
                tvSite.setText(bundle.getString("site"));
            }else{
                llSite.setVisibility(View.GONE);
            }
            if(!bundle.getString("rua").equals("")){
                cvAddress.setVisibility(View.VISIBLE);
                llRua.setVisibility(View.VISIBLE);
                tvRua.setText(bundle.getString("rua"));
            }else{
                llRua.setVisibility(View.GONE);
            }
            if(!bundle.getString("complemento").equals("")){
                cvAddress.setVisibility(View.VISIBLE);
                llComplemento.setVisibility(View.VISIBLE);
                tvComplemento.setText(bundle.getString("complemento"));
            }else{
                llComplemento.setVisibility(View.GONE);
            }
            if(!bundle.getString("cidade").equals("")){
                cvAddress.setVisibility(View.VISIBLE);
                llCidade.setVisibility(View.VISIBLE);
                tvCidade.setText(bundle.getString("cidade"));
            }else{
                llCidade.setVisibility(View.GONE);
            }

            if(!bundle.getString("horario").equals("") || !bundle.getString("dia_semana").equals(" até ")){
                cvTime.setVisibility(View.VISIBLE);
                tvTime.setText(bundle.getString("horario"));
                tvWeekend.setText(bundle.getString("dia_semana"));
            }else{
                cvTime.setVisibility(View.GONE);
            }

            if(!bundle.getString("estado").equals("")){
                cvAddress.setVisibility(View.VISIBLE);
                llEstado.setVisibility(View.VISIBLE);
                tvEstado.setText(bundle.getString("estado"));
            }else{
                llEstado.setVisibility(View.GONE);
            }

            if(!bundle.getString("bairro").equals("")){
                cvAddress.setVisibility(View.VISIBLE);
                llBairro.setVisibility(View.VISIBLE);
                tvBairro.setText(bundle.getString("bairro"));
            }else{
                llBairro.setVisibility(View.GONE);
            }

            if(!bundle.getString("numero").equals("")){
                cvAddress.setVisibility(View.VISIBLE);
                llNumero.setVisibility(View.VISIBLE);
                tvNumero.setText(bundle.getString("numero"));
            }else{
                llNumero.setVisibility(View.GONE);
            }

        }

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        return rootView;
    }
}
