package com.waveofhelp.walp.walp.Fragments.DescriptionsFragments;

/**
 * Created by Pedro on 12/03/2018.
 */

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.waveofhelp.walp.walp.R;

import java.util.regex.Pattern;

public class Description4 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        View rootView = inflater.inflate(R.layout.description4, container, false);

        TextView tx = rootView.findViewById(R.id.logoDrawn);
        Typeface custom_font = Typeface.createFromAsset(getActivity().getAssets(), "fonts/Bello-Pro.ttf");
        tx.setTypeface(custom_font);

        String termsAndConditions = "Termos e Condições";
        String privacyPolicy = "Política de Privacidade";
        TextView legalDescription = rootView.findViewById(R.id.legal_description);

        legalDescription.setText(
                String.format(
                        "Ao continuar, você está indicando que " +
                                "leu a Política de Privacidade e aceita " +
                                " aos Termos e Condições.",
                        termsAndConditions,
                        privacyPolicy)
        );
        legalDescription.setMovementMethod(LinkMovementMethod.getInstance());

        Pattern termsAndConditionsMatcher = Pattern.compile(termsAndConditions);
        Linkify.addLinks(legalDescription, termsAndConditionsMatcher, "http://walpweb.com.br/");

        Pattern privacyPolicyMatcher = Pattern.compile(privacyPolicy);
        Linkify.addLinks(legalDescription, privacyPolicyMatcher, "http://walpweb.com.br/");
        return rootView;
    }
}