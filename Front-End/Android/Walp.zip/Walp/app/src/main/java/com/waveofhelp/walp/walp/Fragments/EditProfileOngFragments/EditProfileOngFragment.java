package com.waveofhelp.walp.walp.Fragments.EditProfileOngFragments;

import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.waveofhelp.walp.walp.Activity.LoginActivity;
import com.waveofhelp.walp.walp.Activity.SignUpOngActivity.Address;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.NetworkControllers.CustomVolleyRequest;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;
import static com.facebook.FacebookSdk.getApplicationContext;

public class EditProfileOngFragment extends Fragment implements View.OnClickListener {

    //Our data for server request
    private String url = Constants.URL_PERFIL_ONG;
    private String urlSendData = Constants.URL_UPDATE_ONG;
    private String ongEmail = Constants.EMAIL_SHARED_PREF;
    private RequestQueue queue;
    private Bitmap bitmap;

    private int mHour, mMinute;

    private int PICK_IMAGE_REQUEST = 1;
    private com.waveofhelp.walp.walp.Activity.SignUpOngActivity.Util util;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    //DATA GET
    private String telefoneOng, latOng, longOng, siteOng, ruaOng, bairroOng, complementoOng, numeroOng, cidadeOng, estadoOng, nomeOng, sobreOng, cepOng, imageOng, tipoOng, timeStart, timeEnd, weekendStartOng, weekendFinishOng;

    private CircleImageView circleImageView;

    private EditText et_name, et_about, et_email, et_phone, et_zip, et_city, et_neighbourhood, et_number, et_complement, et_street, et_site;

    private RelativeLayout background;

    private Button sendDataButton, removeButton, timeStartButton, timeEndButton;

    private String status;

    private Spinner spStates, spOngType, spWeekStart, spWeekEnd;

    private ProgressBar progressBarStreet, progressBarComplemento, progressBarBairro, progressBarCidade, progressBarEstado;

    private String id, email, type;

    private FrameLayout frameLayoutButton;

    public EditProfileOngFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_edit_profile_ong, container, false);

        circleImageView = rootView.findViewById(R.id.profile_photo);
        sendDataButton = rootView.findViewById(R.id.send_data_button);
        frameLayoutButton = rootView.findViewById(R.id.frame_button);
        et_name = rootView.findViewById(R.id.et_name);
        et_about = rootView.findViewById(R.id.et_about);
        et_email = rootView.findViewById(R.id.et_email);
        et_phone = rootView.findViewById(R.id.et_phone_number);
        et_zip = rootView.findViewById(R.id.zip_code);
        et_city = rootView.findViewById(R.id.cidade);
        et_neighbourhood = rootView.findViewById(R.id.bairro);
        et_number = rootView.findViewById(R.id.et_number);
        et_complement = rootView.findViewById(R.id.complemento);
        et_street = rootView.findViewById(R.id.street);
        et_site = rootView.findViewById(R.id.et_site);
        background = rootView.findViewById(R.id.background_banner_rl);
        removeButton = rootView.findViewById(R.id.remove_button);
        timeStartButton = rootView.findViewById(R.id.time_start);
        timeEndButton = rootView.findViewById(R.id.time_end);

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");
        email = sharedPreferences.getString(Constants.EMAIL_SHARED_PREF, "email");
        type = sharedPreferences.getString(Constants.USER_TYPE_SHARED_PREF, "0");

        progressBarStreet = rootView.findViewById(R.id.progressBarStreet);

        progressBarComplemento = rootView.findViewById(R.id.progressBarComplement);

        progressBarBairro = rootView.findViewById(R.id.progressBarBairro);

        progressBarCidade = rootView.findViewById(R.id.progressBarCity);

        progressBarEstado = rootView.findViewById(R.id.progressBarState);

        spStates = rootView.findViewById(R.id.estado);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.states, android.R.layout.simple_spinner_item);
        spStates.setAdapter(adapter);

        spOngType = rootView.findViewById(R.id.ong_type);
        ArrayAdapter<CharSequence> adapterOngType = ArrayAdapter.createFromResource(getContext(), R.array.types, android.R.layout.simple_spinner_dropdown_item);
        spOngType.setAdapter(adapterOngType);

        spWeekStart = rootView.findViewById(R.id.sp_day_week);
        ArrayAdapter<CharSequence> adapterWeek = ArrayAdapter.createFromResource(getContext(), R.array.weekend, android.R.layout.simple_spinner_item);
        spWeekStart.setAdapter(adapterWeek);

        spWeekEnd = rootView.findViewById(R.id.sp_day_week_2);
        ArrayAdapter<CharSequence> adapterWeek2 = ArrayAdapter.createFromResource(getContext(), R.array.weekend, android.R.layout.simple_spinner_item);
        spWeekEnd.setAdapter(adapterWeek2);

        queue = Volley.newRequestQueue(getContext());
        getData();

        removeButton.setOnClickListener(this);
        timeStartButton.setOnClickListener(this);
        timeEndButton.setOnClickListener(this);
        background.setOnClickListener(this);
        sendDataButton.setOnClickListener(this);

        return rootView;
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getApplicationContext()).getRequestQueue();

        //Volley's inbuilt class to make Json array request
        return new JsonArrayRequest(Request.Method.GET, url + "?id_ONG=" + id, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        }) {
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    String jsonString = new String(response.data,
                            HttpHeaderParser
                                    .parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString),
                            HttpHeaderParser
                                    .parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                } catch (JSONException je) {
                    return Response.error(new ParseError(je));
                }
            }
        };
    }

    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {
            JSONObject json;
            try {
                //Getting json
                json = array.getJSONObject(i);



                //Adding data to the ONG object
                telefoneOng = (json.getString("TEL_ONG"));
                latOng = (json.getString("LAT_ONG"));
                longOng = (json.getString("LONG_ONG"));
                sobreOng = (json.getString("SOBRE_ONG"));
                siteOng = (json.getString("SITE_ONG"));
                tipoOng = (json.getString("TIPO_ONG"));
                weekendStartOng = (json.getString("DIARECE"));
                weekendFinishOng = (json.getString("DIAENCE"));
                nomeOng = (json.getString("NOME_ONG"));
                ruaOng = (json.getString("RUA_ONG"));
                complementoOng = (json.getString("COMPLE_ONG"));
                timeStart = (json.getString("HORARECE"));
                timeEnd = (json.getString("HORAENCE"));
                numeroOng = (json.getString("NUMERO_ONG"));
                bairroOng = (json.getString("BAIRRO_ONG"));
                estadoOng = (json.getString("ESTADO_ONG"));
                cidadeOng = (json.getString("CIDADE_ONG"));
                cepOng = (json.getString("CEP_ONG"));
                imageOng = (json.getString("LOGO_ONG"));

                initBackgroundImage();
                setData();
                textWatchers();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    private void initBackgroundImage() {
        String metadataURL = "https://maps.googleapis.com/maps/api/streetview/metadata?size=800x800&location=" + latOng + "," + longOng + "&fov=90&heading=190&pitch=10&key=AIzaSyC5MEFT4j3evHyyc7R_lOZooG6_iBAX7WU";


        // Initialize a new RequestQueue instance
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

        // Initialize a new JsonArrayRequest instance
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, metadataURL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                // Do something with response
                // Process the JSON
                try {
                    // Get the current student (json object) data
                    status = response.getString("status");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (status.equalsIgnoreCase("OK")) {
                    int relLayoutWidth = background.getWidth();
                    int relLayoutHeight = background.getHeight();

                    String imageURL = "https://maps.googleapis.com/maps/api/streetview?size=800x800&location=" + latOng + "," + longOng + "&fov=90&heading=190&pitch=10&key=AIzaSyDQobmny8IukXu2RxCfqLqs1_3-WWwRrIA";
                    Glide.with(getContext())
                            .asBitmap()
                            .load(imageURL)
                            .into(new SimpleTarget<Bitmap>(relLayoutWidth, relLayoutHeight) {

                                @Override
                                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                    Drawable drawable = new BitmapDrawable(resource);
                                    background.setBackground(drawable);
                                }
                            });
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Do something when error occurred
                    }
                }
        );

        // Add JsonArrayRequest to the RequestQueue
        requestQueue.add(jsonObjectRequest);
    }

    private void setData() {
        if (!sobreOng.equals("")) {
            et_about.setText(sobreOng, TextView.BufferType.EDITABLE);
        }

        if (!siteOng.equals("")) {
            et_site.setText(siteOng, TextView.BufferType.EDITABLE);
        }

        if (!complementoOng.equals("")) {
            et_complement.setText(complementoOng, TextView.BufferType.EDITABLE);
        }

        if (!timeStart.equals("")) {
            timeStartButton.setText(timeStart);
        }

        if (!timeEnd.equals("")) {
            timeEndButton.setText(timeEnd);
        }

        if (!complementoOng.equals("")) {
            et_complement.setText(complementoOng, TextView.BufferType.EDITABLE);
        }

        et_name.setText(nomeOng, TextView.BufferType.EDITABLE);
        et_email.setText(email, TextView.BufferType.EDITABLE);
        et_phone.setText(telefoneOng, TextView.BufferType.EDITABLE);
        et_zip.setText(cepOng, TextView.BufferType.EDITABLE);
        et_city.setText(cidadeOng, TextView.BufferType.EDITABLE);
        et_neighbourhood.setText(bairroOng, TextView.BufferType.EDITABLE);
        et_number.setText(numeroOng, TextView.BufferType.EDITABLE);

        if (!ruaOng.equals("")) {
            et_street.setText(ruaOng, TextView.BufferType.EDITABLE);
        }

        setSpinner(R.id.estado, R.array.states, estadoOng);
        setSpinner(R.id.ong_type, R.array.types, tipoOng);
        setSpinner(R.id.sp_day_week, R.array.weekend, weekendStartOng);
        setSpinner(R.id.sp_day_week_2, R.array.weekend, weekendFinishOng);

        ImageLoader imageLoader = CustomVolleyRequest.getInstance(getContext()).getImageLoader();
        imageLoader.get(imageOng, ImageLoader.getImageListener(circleImageView, R.drawable.image, android.R.drawable.ic_dialog_alert));
        Bitmap bitmapImageOng = ((BitmapDrawable) circleImageView.getDrawable()).getBitmap();
        circleImageView.setImageBitmap(bitmapImageOng);
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    @Override
    public void onClick(View view) {

        if (view == sendDataButton) {
            sendOngServerData();
        }

        if (view == background) {
            showFileChooser();
        }

        if(view==timeStartButton){
            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(),
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            String hours, min;

                            if(hourOfDay <10){hours = "0"+hourOfDay;}else{hours = Integer.toString(hourOfDay);}

                            if(minute<10){min="0"+minute;}else{min = Integer.toString(minute);}

                            timeStartButton.setText(hours + ":" + min);
                        }
                    }, mHour, mMinute, true);
            timePickerDialog.setTitle("Abre às");
            timePickerDialog.show();
        }

        if (view == timeEndButton){
            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(),
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            String hours, min;

                            if(hourOfDay <10){hours = "0"+hourOfDay;}else{hours = Integer.toString(hourOfDay);}

                            if(minute<10){min="0"+minute;}else{min = Integer.toString(minute);}

                            timeEndButton.setText(hours + ":" + min);
                        }
                    }, mHour, mMinute, true);
            timePickerDialog.setTitle("Fecha às");
            timePickerDialog.show();
        }

        if (view == removeButton) {
            //Creating an alert dialog to confirm logout
            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
            alertDialogBuilder.setMessage("Tem certeza que deseja remover a sua conta?");
            alertDialogBuilder.setPositiveButton("Sim",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            sendRemove();
                        }
                    });

            alertDialogBuilder.setNegativeButton("Não",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                        }
                    });

            //Showing the alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri filePath = data.getData();
            try {
                //Getting the Bitmap from Gallery
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getApplicationContext().getContentResolver(), filePath);
                circleImageView.setImageBitmap(bitmap);
                frameLayoutButton.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void showFileChooser() {

        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");

        Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent chooserIntent = Intent.createChooser(getIntent, "Selecione a imagem");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickIntent});

        startActivityForResult(chooserIntent, PICK_IMAGE_REQUEST);
    }

    private void sendOngServerData() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSendData,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //If we are getting success from server
                        if (response.equalsIgnoreCase(Constants.Success)) {
                            frameLayoutButton.setVisibility(View.GONE);
                            Toast.makeText(getApplicationContext(), "Alteração efetuada", Toast.LENGTH_LONG).show();
                        } else {
                            frameLayoutButton.setVisibility(View.GONE);
                            Toast.makeText(getContext(), "A alteração não pode ser feita", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                        Toast.makeText(getApplicationContext(), "Verifique a sua conexão", Toast.LENGTH_LONG).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                String nome, sobre, email, telefone, cep, cidade, bairro, complemento, numero, rua, site, image, estado, tipo, horaece, horaence, weekendStart, weekendEnd;

                nome = et_name.getText().toString();
                sobre = et_about.getText().toString();
                email = et_email.getText().toString();
                telefone = et_phone.getText().toString();
                cep = et_zip.getText().toString();
                numero = et_number.getText().toString();
                cidade = et_city.getText().toString();
                bairro = et_neighbourhood.getText().toString();
                complemento = et_complement.getText().toString();
                rua = et_street.getText().toString();
                site = et_site.getText().toString();
                tipo = spOngType.getSelectedItem().toString();
                estado = spStates.getSelectedItem().toString();

                if(!timeStartButton.getText().toString().equals("Horário...") && !timeEndButton.getText().toString().equals("Horário...") && !spWeekStart.getSelectedItem().toString().equals("Dia") && !spWeekEnd.getSelectedItem().toString().equals("Dia")){
                    horaece = timeStartButton.getText().toString();
                    horaence = timeEndButton.getText().toString();
                    weekendStart = spWeekStart.getSelectedItem().toString();
                    weekendEnd = spWeekEnd.getSelectedItem().toString();

                }else{
                    horaece = "";
                    horaence = "";
                    weekendStart = "";
                    weekendEnd = "";
                    Toast.makeText(getContext(),"O período não foi preenchido corretamente",Toast.LENGTH_LONG).show();
                }


                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();

                params.put("id_ONG", id);
                params.put("sobre_ONG", sobre);
                params.put("nome_ONG", nome);
                params.put("email_ONG", email);
                params.put("tel_ONG", telefone);
                params.put("cep_ONG", cep);
                params.put("cidade_ONG", cidade);
                params.put("bairro_ONG", bairro);
                params.put("complemento_ONG", complemento);
                params.put("numero_ONG", numero);
                params.put("rua_ONG", rua);
                params.put("site_ONG", site);
                params.put("tipo_ONG", tipo);
                params.put("estado_ONG", estado);
                params.put("horarece_ONG", horaece);
                params.put("horaence_ONG", horaence);
                params.put("diarece_ONG",weekendStart);
                params.put("diaence_ONG",weekendEnd);

                if (bitmap != null) {
                    image = getStringImage(bitmap);
                    params.put("logo_ONG", image);
                } else {
                    params.put("logo_ONG", imageOng);
                }


                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

    //private String getZipCode(){
    //    return et_zip.getText().toString();
    //}

    //public String getUriRequest(){
    //    return "https://viacep.com.br/ws/"+getZipCode()+"/json/";
    //}

    public void lockFields(boolean isToLock) {
        et_street.setVisibility(View.GONE);
        et_complement.setVisibility(View.GONE);
        et_neighbourhood.setVisibility(View.GONE);
        et_city.setVisibility(View.GONE);
        spStates.setVisibility(View.GONE);
        progressBarStreet.setVisibility(View.VISIBLE);
        progressBarComplemento.setVisibility(View.VISIBLE);
        progressBarBairro.setVisibility(View.VISIBLE);
        progressBarCidade.setVisibility(View.VISIBLE);
        progressBarEstado.setVisibility(View.VISIBLE);

        util.lockFields(isToLock);
    }

    public void setAddressFields(Address address) {

        //Set charge visible
        progressBarStreet.setVisibility(View.GONE);
        progressBarComplemento.setVisibility(View.GONE);
        progressBarBairro.setVisibility(View.GONE);
        progressBarCidade.setVisibility(View.GONE);

        et_street.setVisibility(View.VISIBLE);
        et_complement.setVisibility(View.VISIBLE);
        et_neighbourhood.setVisibility(View.VISIBLE);
        et_city.setVisibility(View.VISIBLE);

        setField(R.id.street, address.getLogradouro());
        setField(R.id.complemento, address.getComplemento());
        setField(R.id.bairro, address.getBairro());
        setField(R.id.cidade, address.getLocalidade());
        setSpinner(R.id.estado, R.array.states, address.getUf());
    }

    private void setField(int fieldId, String data) {
        ((EditText) getActivity().findViewById(fieldId)).setText(data);
    }

    private void setSpinner(int fieldId, int arrayId, String uf) {
        Spinner spinner = getActivity().findViewById(fieldId);
        String[] states = getResources().getStringArray(arrayId);

        progressBarEstado.setVisibility(View.GONE);
        progressBarEstado.setVisibility(View.GONE);
        spStates.setVisibility(View.VISIBLE);

        for (int i = 0; i < states.length; i++) {
            if (states[i].equals(uf)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private void textWatchers() {

        TextWatcher zipCodeTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                String zipCode = s.toString();

                if (zipCode.length() == 8) {
                    //new AddressRequestEditProfileOng((EditProfileOngFragment) getContext()).execute();
                }
            }
        };

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                frameLayoutButton.setVisibility(View.VISIBLE);
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        };

        et_name.addTextChangedListener(textWatcher);
        et_about.addTextChangedListener(textWatcher);
        et_email.addTextChangedListener(textWatcher);
        et_phone.addTextChangedListener(textWatcher);
        et_city.addTextChangedListener(textWatcher);
        et_neighbourhood.addTextChangedListener(textWatcher);
        et_complement.addTextChangedListener(textWatcher);
        et_street.addTextChangedListener(textWatcher);
        et_site.addTextChangedListener(textWatcher);
        et_zip.addTextChangedListener(textWatcher);
        timeStartButton.addTextChangedListener(textWatcher);
        timeEndButton.addTextChangedListener(textWatcher);

        et_zip.addTextChangedListener(zipCodeTextWatcher);
        util = new com.waveofhelp.walp.walp.Activity.SignUpOngActivity.Util(getActivity(), R.id.street, R.id.complemento, R.id.bairro, R.id.cidade, R.id.estado);
    }

    private void sendRemove() {
        String url = Constants.URL_DELETE_ONG;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.equalsIgnoreCase("false")) {
                            //If the server response is not success
                            //Displaying an error message on toast
                            Toast.makeText(getContext(), "Tente novamente mais tarde", Toast.LENGTH_LONG).show();
                        } else {
                            //Getting out sharedpreferences
                            SharedPreferences preferences = getContext().getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                            //Getting editor
                            SharedPreferences.Editor editor = preferences.edit();

                            //Puting the value false for loggedin
                            editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

                            //Putting blank value to email
                            editor.putString(Constants.EMAIL_SHARED_PREF, "");

                            editor.putString(Constants.USER_TYPE_SHARED_PREF, "0");

                            //Saving the sharedpreferences
                            editor.apply();

                            //Starting login activity
                            Intent intent = new Intent(getContext(), LoginActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                //Converting Bitmap to String

                Map<String, String> params = new HashMap<String, String>();
                params.put("id_ong", id);

                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

}