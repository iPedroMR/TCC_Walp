package com.waveofhelp.walp.walp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.widget.Filter;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.waveofhelp.walp.walp.Activity.ProfileOngActivity;
import com.waveofhelp.walp.walp.Fragments.ListOngFragments.CustomFilter;
import com.waveofhelp.walp.walp.NetworkControllers.CustomVolleyRequest;
import com.waveofhelp.walp.walp.Objects.NewsFeeds;
import com.waveofhelp.walp.walp.R;

import java.io.ByteArrayOutputStream;
import java.text.DecimalFormat;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Pedro on 27/04/2017.
 */

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.FeedsViewHolder> {

    private Context context;

    //List of all ONGS
    public List<NewsFeeds> newsFeedsList;
    private CustomFilter filter;
    private LayoutInflater inflater;
    private NewsFeeds feeds;

    public RVAdapter(List<NewsFeeds> newsFeedsList, Context context) {
        this.newsFeedsList = newsFeedsList;
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public FeedsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View rootView = inflater.inflate(R.layout.card_item, parent, false);
        return new FeedsViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(final FeedsViewHolder ongViewHolder, final int position) {
        //Getting the particular item from the list
        feeds = newsFeedsList.get(position);

        ongViewHolder.typeOng = feeds.getTIPO_ONG();

        switch (ongViewHolder.typeOng) {
            case "Refugiados":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_account_multiple);
                break;
            case "Crianças":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_human_child);
                break;
            case "Pessoas em situação de rua":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_nature_people_black_24dp);
                break;
            case "Mulheres":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_gender_female);
                break;
            case "Animais":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_donkey);
                break;
            case "Idosos":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_face_black_24dp);
                break;
            case "Pessoa com deficiência":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_wheelchair_accessibility);
                break;
            case "Catástrofes":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_waves);
                break;
            case "Meio ambiente":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_tree);
                break;
            case "Dependentes quimicos":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_smoking_rooms_black_24dp);
                break;
            case "Educação":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_school_black_24dp);
                break;
            case "Direitos humanos":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_gavel_black_24dp);
                break;
            case "Assistência social":
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_home_assistant);
                break;
            default:
                ongViewHolder.categoryOng.setImageResource(R.drawable.ic_error_outline_white_24dp);
                break;
        }

        //Loading image from url
        ImageLoader imageLoader = CustomVolleyRequest.getInstance(context).getImageLoader();
        imageLoader.get(feeds.getIMAGEM_ONG(), ImageLoader.getImageListener(ongViewHolder.ongPhoto, R.drawable.image, android.R.drawable.ic_dialog_info));
        Bitmap bitmap = ((BitmapDrawable) ongViewHolder.ongPhoto.getDrawable()).getBitmap();

        ongViewHolder.imageURL = feeds.getIMAGEM_ONG();

        //Showing data on the views
        ongViewHolder.ongName.setText(feeds.getNOME_ONG());
        ongViewHolder.ongPhoto.setImageBitmap(bitmap);
        ongViewHolder.ongDistance.setText(roundDistance());
        ongViewHolder.idOng = feeds.getID_ONG();
    }

    @Override
    public int getItemCount() {
        return newsFeedsList.size();
    }

    public final class FeedsViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        RelativeLayout rl_cv;
        TextView ongName;
        TextView ongDistance;
        ImageView categoryOng;
        ImageView needs;
        CircleImageView ongPhoto;
        String idOng, typeOng, imageURL;

        private FeedsViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cv = itemView.findViewById(R.id.cv);
            rl_cv = itemView.findViewById(R.id.rl_cv);
            ongName = itemView.findViewById(R.id.ong_name);
            ongDistance = itemView.findViewById(R.id.ong_distance);
            ongPhoto = itemView.findViewById(R.id.ong_photo);
            categoryOng = itemView.findViewById(R.id.category_ong);
            needs = itemView.findViewById(R.id.needs);

            rl_cv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    String textName = ongName.getText().toString();
                    String textDistance = ongDistance.getText().toString();

                    Class destinationActivity = ProfileOngActivity.class;
                    Intent startPortfolioActivityIntent = new Intent(context, destinationActivity);
                    startPortfolioActivityIntent.putExtra(Intent.EXTRA_REFERRER_NAME, textName);
                    startPortfolioActivityIntent.putExtra(Intent.EXTRA_TEXT, textDistance);
                    startPortfolioActivityIntent.putExtra("Image", imageURL);
                    startPortfolioActivityIntent.putExtra("Id", idOng);
                    startPortfolioActivityIntent.putExtra("Type", typeOng);
                    context.startActivity(startPortfolioActivityIntent);
                }
            });
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    //RETURN FILTER OBJ
    public Filter getFilter() {
        if (filter == null) {
            filter = new CustomFilter(newsFeedsList, this);
        }
        return filter;
    }

    private String roundDistance() {

        DecimalFormat decimalFormat = new DecimalFormat("0.#");
        String distanceString = decimalFormat.format(Double.parseDouble(feeds.getDISTANCIA_ONG())) + " km";
        return distanceString;
    }

}