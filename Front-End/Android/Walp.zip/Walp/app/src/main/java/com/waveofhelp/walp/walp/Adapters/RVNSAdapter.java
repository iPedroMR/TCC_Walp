package com.waveofhelp.walp.walp.Adapters;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.data.DataHolder;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.Objects.Needs;
import com.waveofhelp.walp.walp.OnEditTextChanged;
import com.waveofhelp.walp.walp.R;

import java.util.List;

import static android.graphics.Color.BLACK;
import static android.graphics.Color.GRAY;
import static android.graphics.Color.WHITE;

/**
 * Created by beta17 on 19/10/17.
 */

public class RVNSAdapter extends RecyclerView.Adapter<RVNSAdapter.NeedsViewHolder> {

    private Context context;
    public String id, needId;
    private OnEditTextChanged onEditTextChanged;

    public final class NeedsViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        TextView needName;
        TextView needDescription;
        TextView unit;
        ImageView needPhoto;
        String typeNeed, metricNeed;
        EditText editTextQuantity;

        public NeedsViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cv = itemView.findViewById(R.id.card_view_donations);
            needPhoto = itemView.findViewById(R.id.category);
            unit = itemView.findViewById(R.id.tv_unit);
            needName = itemView.findViewById(R.id.need_name);
            needDescription = itemView.findViewById(R.id.need_description);
            editTextQuantity = itemView.findViewById(R.id.edit_text_set_quantity);
        }
    }

    private List<Needs> needsList;

    public RVNSAdapter(List<Needs> needsList, Context context, OnEditTextChanged onEditTextChanged) {
        this.needsList = needsList;
        this.context = context;
        this.onEditTextChanged = onEditTextChanged;
    }


    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public RVNSAdapter.NeedsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_donation_item, parent, false);

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = this.context.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        return new RVNSAdapter.NeedsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final RVNSAdapter.NeedsViewHolder needsViewHolder, final int position) {
        needsViewHolder.needName.setText(needsList.get(position).getName());
        needsViewHolder.needDescription.setText(needsList.get(position).getDescription());
        needsViewHolder.needName.setText(needsList.get(position).getName());
        needsViewHolder.typeNeed = needsList.get(position).getType();
        needsViewHolder.unit.setText(needsList.get(position).getMetric());
        needId = needsList.get(position).getId();

        needsViewHolder.editTextQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                onEditTextChanged.onTextChanged(position, charSequence.toString(), needsList.get(position).getName());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        switch (needsViewHolder.typeNeed) {
            case "Alimentos":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_restaurant_black_24dp);
                break;
            case "Brinquedos":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_toy);
                break;
            case "Roupas e calçados":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_tshirt_crew);
                break;
            case "Produtos higiênicos":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_clean);
                break;
            case "Materiais de limpeza":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_broom);
                break;
            case "Utensilios em geral":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_lead_pencil);
                break;
            case "Móveis":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_weekend_black_24dp);
                break;
            case "Outros":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_more_horiz_black_24dp);
                break;
            default:
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_error_outline_white_24dp);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return needsList.size();
    }

}
