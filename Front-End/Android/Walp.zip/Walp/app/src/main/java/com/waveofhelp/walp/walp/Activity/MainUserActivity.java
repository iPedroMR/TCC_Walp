package com.waveofhelp.walp.walp.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.Fragments.ListDonatedFragment;
import com.waveofhelp.walp.walp.Fragments.ListOngFragments.ListOngFragment;
import com.waveofhelp.walp.walp.R;

public class MainUserActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private static final String TAG = MainUserActivity.class.getSimpleName();
    private BottomNavigationView bottomNavigation;
    private int id;
    private Fragment fragment;
    private FragmentManager fragmentManager;
    private boolean loggedIn = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user);

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        loggedIn = sharedPreferences.getBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

        bottomNavigation = findViewById(R.id.navigation);

        if (savedInstanceState == null && !getIntent().hasExtra("EXTRA")) {
            FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
            tx.replace(R.id.mainContainer, new ListOngFragment());
            tx.commit();
        }else {
            switch (getIntent().getStringExtra("EXTRA")){
                case "openFragment":
                    getSupportFragmentManager().beginTransaction().replace(R.id.mainContainer, new ListDonatedFragment()).commit();
                    bottomNavigation.setSelectedItemId(R.id.activities_action);
                    break;
            }
        }

        String token = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Token: " + token);


        TextView tx = findViewById(R.id.logoDrawn);
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/Bello-Pro.ttf");
        tx.setTypeface(custom_font);

        mToolbar = findViewById(R.id.tb_main);
        mToolbar.setTitle("");
        setSupportActionBar(mToolbar);


        fragmentManager = getSupportFragmentManager();
        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                id = item.getItemId();

                    switch (id) {
                        case R.id.list_action:
                            fragment = new ListOngFragment();
                            break;
                        case R.id.activities_action:
                            fragment = new ListDonatedFragment();
                            break;
                    }
                    final FragmentTransaction transaction = fragmentManager.beginTransaction();
                    transaction.replace(R.id.mainContainer, fragment).commit();
                return true;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem backcadastro = menu.findItem(R.id.back_cadastro);
        MenuItem logout = menu.findItem(R.id.logout);
        MenuItem edituser = menu.findItem(R.id.edit_user);

        if (!loggedIn) {
            backcadastro.setVisible(true);
            logout.setVisible(false);
            edituser.setVisible(false);
        } else {
            backcadastro.setVisible(false);
            logout.setVisible(true);
            edituser.setVisible(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.back_cadastro:
                startActivity(new Intent(this, WelcomeActivity.class));
                finish();
                return true;
            case R.id.logout:
                //Creating an alert dialog to confirm logout
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setMessage("Tem certeza que deseja fazer sair da sua conta?");
                alertDialogBuilder.setPositiveButton("Sim",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {

                                //Getting out sharedpreferences
                                SharedPreferences preferences = getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                                //Getting editor
                                SharedPreferences.Editor editor = preferences.edit();

                                //Puting the value false for loggedin
                                editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

                                //Putting blank value to email
                                editor.putString(Constants.EMAIL_SHARED_PREF, "");

                                editor.putString(Constants.USER_TYPE_SHARED_PREF, "0");

                                //Saving the sharedpreferences
                                editor.commit();

                                //Starting login activity
                                Intent intent = new Intent(MainUserActivity.this, LoginActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });

                alertDialogBuilder.setNegativeButton("Não",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {

                            }
                        });

                //Showing the alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

                return true;

            case R.id.edit_user:
                startActivity(new Intent(this, ProfileSettingsActivity.class));
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}


