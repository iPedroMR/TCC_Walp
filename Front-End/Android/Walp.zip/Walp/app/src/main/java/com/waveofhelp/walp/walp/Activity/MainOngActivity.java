package com.waveofhelp.walp.walp.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.Fragments.EditProfileOngFragments.EditProfileOngFragment;
import com.waveofhelp.walp.walp.Fragments.ListDonatedOngFragment;
import com.waveofhelp.walp.walp.Fragments.ListDonationFragment;
import com.waveofhelp.walp.walp.R;

public class MainOngActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private static final String TAG = MainOngActivity.class.getSimpleName();
    private BottomNavigationView bottomNavigation;
    private Fragment fragment;
    private FragmentManager fragmentManager;
    private boolean loggedIn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ong);

        //if (AccessToken.getCurrentAccessToken() == null){
        //    goLoginScreen();
        //}

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        loggedIn = sharedPreferences.getBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

        if(savedInstanceState == null) {
            FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
            tx.replace(R.id.mainContainer, new EditProfileOngFragment());
            tx.commit();
        }

        String token = FirebaseInstanceId.getInstance().getToken();

        TextView tx = findViewById(R.id.logoDrawn);
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "fonts/Bello-Pro.ttf");
        tx.setTypeface(custom_font);

        mToolbar = findViewById(R.id.tb_main);
        mToolbar.setTitle("");
        setSupportActionBar(mToolbar);

        bottomNavigation = findViewById(R.id.navigation_ong);
        fragmentManager = getSupportFragmentManager();
        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                //Adicionar função para não permitir que o item selecionado recarregue

                switch (id){
                    case R.id.port_action:
                        fragment = new EditProfileOngFragment();
                        break;
                    case R.id.need_action:
                        fragment = new ListDonationFragment();
                        break;
                    case R.id.donation_action:
                        fragment = new ListDonatedOngFragment();
                        break;
                }

                final FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.replace(R.id.mainContainer, fragment).commit();
                return true;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem backcadastro = menu.findItem(R.id.back_cadastro);
        MenuItem logout = menu.findItem(R.id.logout);
        MenuItem edituser = menu.findItem(R.id.edit_user);
        edituser.setVisible(false);

        if (!loggedIn) {
            backcadastro.setVisible(true);
            logout.setVisible(false);
        } else {
            backcadastro.setVisible(false);
            logout.setVisible(true);
        }
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        MenuItem logout = menu.findItem(R.id.logout);
        logout.setVisible(true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        switch (item.getItemId()) {
            case R.id.back_cadastro:
                startActivity(new Intent(this, WelcomeActivity.class));
                finish();
                return true;
            case R.id.logout:
                //Creating an alert dialog to confirm logout
                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setMessage("Tem certeza que deseja fazer sair da sua conta?");
                alertDialogBuilder.setPositiveButton("Sim",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {

                                //Getting out sharedpreferences
                                SharedPreferences preferences = getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                                //Getting editor
                                SharedPreferences.Editor editor = preferences.edit();

                                //Puting the value false for loggedin
                                editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, false);

                                //Putting blank value to email
                                editor.putString(Constants.EMAIL_SHARED_PREF, "");

                                editor.putString(Constants.USER_TYPE_SHARED_PREF, "0");

                                //Saving the sharedpreferences
                                editor.commit();

                                //Starting login activity
                                Intent intent = new Intent(MainOngActivity.this, LoginActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });

                alertDialogBuilder.setNegativeButton("Não",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                            }
                        });

                //Showing the alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
