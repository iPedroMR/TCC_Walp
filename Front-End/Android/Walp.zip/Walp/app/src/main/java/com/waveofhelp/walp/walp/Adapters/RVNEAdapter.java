package com.waveofhelp.walp.walp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Activity.EditNeedActivity;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.Fragments.ListDonationFragment;
import com.waveofhelp.walp.walp.Objects.Needs;
import com.waveofhelp.walp.walp.R;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by beta17 on 19/10/17.
 */

public class RVNEAdapter extends RecyclerView.Adapter<RVNEAdapter.NeedsViewHolder> {

    Context context;
    String id, needId;

    public final class NeedsViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        TextView needName;
        TextView needDescription;
        ImageView needPhoto;
        String typeNeed, metricNeed;
        ImageButton editButton;

        public NeedsViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cv = itemView.findViewById(R.id.card_view_donations);
            needPhoto = itemView.findViewById(R.id.category);
            needName = itemView.findViewById(R.id.need_name);
            needDescription = itemView.findViewById(R.id.need_description);
            editButton = itemView.findViewById(R.id.button_edit);

            editButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {

                            String textName = needName.getText().toString();
                            String textDescription = needDescription.getText().toString();

                            Class destinationActivity = EditNeedActivity.class;
                            Intent startPortfolioActivityIntent = new Intent(context, destinationActivity);
                            startPortfolioActivityIntent.putExtra("name", textName);
                            startPortfolioActivityIntent.putExtra("description", textDescription);
                            startPortfolioActivityIntent.putExtra("type", typeNeed);
                            startPortfolioActivityIntent.putExtra("metric",metricNeed);
                            startPortfolioActivityIntent.putExtra("id", needId);
                            context.startActivity(startPortfolioActivityIntent);
                        }
                    });
        }
    }

    private List<Needs> needsList;

    public RVNEAdapter(List<Needs> needsList, Context context) {
        this.needsList = needsList;
        this.context = context;
    }


    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public RVNEAdapter.NeedsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_edit_donation, parent, false);

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = this.context.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        return new RVNEAdapter.NeedsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final RVNEAdapter.NeedsViewHolder needsViewHolder, final int position) {
        needsViewHolder.needName.setText(needsList.get(position).getName());
        needsViewHolder.needDescription.setText(needsList.get(position).getDescription());
        needsViewHolder.typeNeed = needsList.get(position).getType();
        needsViewHolder.metricNeed = needsList.get(position).getMetric();
        needId = needsList.get(position).getId();

        switch (needsViewHolder.typeNeed) {
            case "Alimentos":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_restaurant_black_24dp);
                break;
            case "Brinquedos":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_toy);
                break;
            case "Roupas e calçados":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_tshirt_crew);
                break;
            case "Produtos higiênicos":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_clean);
                break;
            case "Materiais de limpeza":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_broom);
                break;
            case "Utensilios em geral":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_lead_pencil);
                break;
            case "Móveis":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_weekend_black_24dp);
                break;
            case "Outros":
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_more_horiz_black_24dp);
                break;
            default:
                needsViewHolder.needPhoto.setImageResource(R.drawable.ic_error_outline_white_24dp);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return needsList.size();
    }

}
