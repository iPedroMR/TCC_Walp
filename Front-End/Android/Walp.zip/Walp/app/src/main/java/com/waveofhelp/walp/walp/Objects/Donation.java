package com.waveofhelp.walp.walp.Objects;

/**
 * Created by Pedro on 11/05/2017.
 */
public class Donation {
    public String name;
    public String data;
    public String time;
    public String status;
    public String nameOng;
    public int photoDonation;

    public Donation(String name, String nameOng, String data, String status, String time, int photoDonation) {
        this.name = name;
        this.time = time;
        this.nameOng = nameOng;
        this.data = data;
        this.status = status;
        this.photoDonation = photoDonation;
    }
}
