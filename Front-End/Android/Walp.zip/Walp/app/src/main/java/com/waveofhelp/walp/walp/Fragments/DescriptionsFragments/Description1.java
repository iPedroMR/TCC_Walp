package com.waveofhelp.walp.walp.Fragments.DescriptionsFragments;

/**
 * Created by Pedro on 18/03/2017.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.waveofhelp.walp.walp.R;

public class Description1 extends Fragment{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        return inflater.inflate(R.layout.description1,container,false);
    }

}
