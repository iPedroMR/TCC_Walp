package com.waveofhelp.walp.walp.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.Fragments.ListDonationFragment;
import com.waveofhelp.walp.walp.R;

import java.util.HashMap;
import java.util.Map;

public class CreateEditNeedActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etName, etDescription;
    private Spinner spType, spMetric;
    private Button confirmNeed;
    private String textName, textDescription, textType, id, textMetric;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_edit_need);

        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the value form sharedpreferences
        id = sharedPreferences.getString(Constants.ID_SHARED_PREF, "0");

        etName = findViewById(R.id.name);
        etDescription = findViewById(R.id.description);
        spType = findViewById(R.id.sp_need_type);
        spMetric = findViewById(R.id.sp_metric);
        confirmNeed = findViewById(R.id.button_confirm_need);


        ArrayAdapter<CharSequence> adapterType = ArrayAdapter.createFromResource(this, R.array.need_type, android.R.layout.simple_spinner_dropdown_item);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.unit_metrics, android.R.layout.simple_spinner_dropdown_item);

        spType.setAdapter(adapterType);
        spMetric.setAdapter(adapter);

        confirmNeed.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == confirmNeed) {
            if(verifyData()) {
                sendData();
            }
        }
    }

    private boolean verifyData(){

        boolean valid = true;

        textName = etName.getText().toString();
        textDescription = etDescription.getText().toString();
        textType = spType.getSelectedItem().toString().trim();
        textMetric = spMetric.getSelectedItem().toString().trim();

        if (textName.isEmpty() || textName.length() < 1) {
            etName.setError("Entre com um nome válido");
            valid = false;
        } else {
            etName.setError(null);
        }

        if (textType.isEmpty() || textType.equals("Tipo da ONG")) {
            valid = false;
        }

        if (textType.isEmpty() || textType.equals("Categoria")) {
            valid = false;
        }

        if (textMetric.isEmpty() || textMetric.equals("Sem unidade")) {
            textMetric = "";
        }

        return valid;
    }

    private void sendData(){
        String url = Constants.URL_INSERT_NEED;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if(response.equalsIgnoreCase("false")){
                            //If the server response is not success
                            //Displaying an error message on toast
                            Toast.makeText(CreateEditNeedActivity.this,"Tente novamente mais tarde",Toast.LENGTH_LONG).show();
                        } else {

                            //Starting profile activity
                            onBackPressed();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Dismissing the progress dialog
                        Toast.makeText(CreateEditNeedActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                    }
                }){

            @Override
            protected Map<String,String> getParams() throws AuthFailureError {

                //Converting Bitmap to String

                Map<String,String> params = new HashMap<String, String>();

                params.put("id_ong",id);
                params.put("necessidade",textName);
                params.put("descricao", textDescription);
                params.put("tipo_nece",textType);
                params.put("unidade",textMetric);

                return params;

            }

        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
