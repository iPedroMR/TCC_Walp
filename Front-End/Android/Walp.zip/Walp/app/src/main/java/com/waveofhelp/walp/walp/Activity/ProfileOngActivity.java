package com.waveofhelp.walp.walp.Activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.waveofhelp.walp.walp.*;
import com.waveofhelp.walp.walp.NetworkControllers.CustomVolleyRequest;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;
import com.waveofhelp.walp.walp.Fragments.ProfileOngFragments.AboutFragment;
import com.waveofhelp.walp.walp.Fragments.ProfileOngFragments.LocalFragment;
import com.waveofhelp.walp.walp.Fragments.ProfileOngFragments.NeedsFragment;
import com.waveofhelp.walp.walp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileOngActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener {

    private TextView mOngDistance;
    private TextView mOngType;
    private CircleImageView mOngLogo;
    private ImageView categoryOng, src;

    private static final int MY_PERMISSION_REQUEST_CODE = 0;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 0;

    private ProgressBar progressBarBackgroundImage, progressBarViewPager;

    //Check user network
    boolean connected = false;

    //This is our tablayout
    private TabLayout tabLayout;

    //This is our viewPager
    private WrappingViewPager viewPager;

    //Our data for server request
    private String url = Constants.URL_PERFIL_ONG;

    private String textName, idOng;

    //The request counter to send ?page=1, ?page=2  requests
    private int requestCount = 1;

    //DATA GET
    private String telefoneOng, latOng, longOng, status;

    Bundle bundle = new Bundle();

    Bundle bundle1 = new Bundle();

    Bundle bundle2 = new Bundle();

    RequestQueue queue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.waveofhelp.walp.walp.R.layout.activity_profile_ong);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        TextView mOngName = findViewById(R.id.user_profile_name);
        mOngDistance = findViewById(R.id.ong_distance);
        mOngLogo = findViewById(R.id.user_profile_photo);
        mOngType = findViewById(R.id.tv_type);
        categoryOng = findViewById(R.id.category_ong);

        progressBarBackgroundImage = findViewById(R.id.progress_bar_background_image);
        progressBarViewPager = findViewById(R.id.progress_bar_view_pager);

        final Drawable upArrow = getResources().getDrawable(R.drawable.abc_ic_ab_back_material);
        upArrow.setColorFilter(getResources().getColor(R.color.cardview_light_background), PorterDuff.Mode.SRC_ATOP);
        getSupportActionBar().setHomeAsUpIndicator(upArrow);

        Intent intentThatStartedThisActivity = getIntent();

        if (intentThatStartedThisActivity.hasExtra(Intent.EXTRA_REFERRER_NAME)) {
            textName = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_REFERRER_NAME);
            mOngName.setText(textName);
        }

        if (intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT)) {
            String textDistance = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT);
            mOngDistance.setText(textDistance);
        }

        if (intentThatStartedThisActivity.hasExtra("Id")) {
            idOng = intentThatStartedThisActivity.getStringExtra("Id");
        }

        if (intentThatStartedThisActivity.hasExtra("Type")) {
            mOngType.setText(intentThatStartedThisActivity.getStringExtra("Type"));

            switch (mOngType.getText().toString()) {
                case "Refugiados":
                    categoryOng.setImageResource(R.drawable.ic_account_multiple);
                    break;
                case "Crianças":
                    categoryOng.setImageResource(R.drawable.ic_human_child);
                    break;
                case "Pessoas em situação de rua":
                    categoryOng.setImageResource(R.drawable.ic_nature_people_black_24dp);
                    break;
                case "Mulheres":
                    categoryOng.setImageResource(R.drawable.ic_gender_female);
                    break;
                case "Animais":
                    categoryOng.setImageResource(R.drawable.ic_donkey);
                    break;
                case "Idosos":
                    categoryOng.setImageResource(R.drawable.ic_face_black_24dp);
                    break;
                case "Pessoa com deficiência":
                    categoryOng.setImageResource(R.drawable.ic_wheelchair_accessibility);
                    break;
                case "Catástrofes":
                    categoryOng.setImageResource(R.drawable.ic_waves);
                    break;
                case "Meio ambiente":
                    categoryOng.setImageResource(R.drawable.ic_tree);
                    break;
                case "Dependentes quimicos":
                    categoryOng.setImageResource(R.drawable.ic_smoking_rooms_black_24dp);
                    break;
                case "Educação":
                    categoryOng.setImageResource(R.drawable.ic_school_black_24dp);
                    break;
                case "Direitos humanos":
                    categoryOng.setImageResource(R.drawable.ic_gavel_black_24dp);
                    break;
                case "Assistência social":
                    categoryOng.setImageResource(R.drawable.ic_home_assistant);
                    break;
                default:
                    categoryOng.setImageResource(R.drawable.ic_error_outline_white_24dp);
                    break;
            }
        }

        if (intentThatStartedThisActivity.hasExtra("Image")) {
            //Loading image from url
            ImageLoader imageLoader = CustomVolleyRequest.getInstance(this).getImageLoader();
            imageLoader.get(intentThatStartedThisActivity.getStringExtra("Image"), ImageLoader.getImageListener(mOngLogo, R.drawable.image, android.R.drawable.ic_dialog_alert));
            Bitmap bitmap = ((BitmapDrawable) mOngLogo.getDrawable()).getBitmap();
            mOngLogo.setImageBitmap(bitmap);
        }

        queue = Volley.newRequestQueue(this);
        getData();
    }

    private JsonArrayRequest getDataFromServer(int requestCount) {
        progressBarBackgroundImage.setVisibility(View.VISIBLE);
        progressBarViewPager.setVisibility(View.VISIBLE);

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getApplicationContext()).getRequestQueue();

        //Volley's inbuilt class to make Json array request
        return new JsonArrayRequest(Request.Method.GET, url + "?id_ONG=" + idOng, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast toast = Toast.makeText(ProfileOngActivity.this, error.toString(), Toast.LENGTH_LONG);
                toast.show();

            }
        }) {
            @Override
            protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
                try {
                    String jsonString = new String(response.data,
                            HttpHeaderParser
                                    .parseCharset(response.headers));
                    return Response.success(new JSONArray(jsonString),
                            HttpHeaderParser
                                    .parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                } catch (JSONException je) {
                    return Response.error(new ParseError(je));
                }
            }
        };
    }

    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer(requestCount));
        //Incrementing the request counter
        requestCount++;
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        for (int i = 0; i < array.length(); i++) {
            JSONObject json;
            try {
                String horaece, horaence, horario, weekend;

                //Getting json
                json = array.getJSONObject(i);
                //Adding data to the ONG object
                latOng = (json.getString("LAT_ONG"));
                longOng = (json.getString("LONG_ONG"));
                telefoneOng = (json.getString("TEL_ONG"));

                horaece = (json.getString("HORARECE"));
                horaence = (json.getString("HORAENCE"));

                if (horaece.isEmpty() || horaence.isEmpty()) {
                    horario = "";
                } else {
                    horario = horaece + " - " + horaence;
                }

                weekend = (json.getString("DIARECE")) + " até " + (json.getString("DIAENCE"));

                bundle.putString("telefone", telefoneOng);
                bundle.putString("email", json.getString("EMAIL_ONG"));
                bundle.putString("site", json.getString("SITE_ONG"));
                bundle.putString("sobre", json.getString("SOBRE_ONG"));
                bundle.putString("rua", json.getString("RUA_ONG"));
                bundle.putString("numero", json.getString("NUMERO_ONG"));
                bundle.putString("bairro", json.getString("BAIRRO_ONG"));
                bundle.putString("complemento", json.getString("COMPLE_ONG"));
                bundle.putString("estado", json.getString("ESTADO_ONG"));
                bundle.putString("cidade", json.getString("CIDADE_ONG"));
                bundle.putString("horario", horario);
                bundle.putString("dia_semana", weekend);
                bundle1.putString("lat_ONG", latOng);
                bundle1.putString("long_ONG", longOng);

                bundle2.putString("id", idOng);


            } catch (JSONException e) {
                e.printStackTrace();
            }
            createFragments();
        }

        initBackgroundImage();
    }

    private void initBackgroundImage() {
        src = findViewById(R.id.header_cover_image);
        String metadataURL = "https://maps.googleapis.com/maps/api/streetview/metadata?size=800x800&location=" + latOng + "," + longOng + "&fov=90&heading=190&pitch=10&key=AIzaSyC5MEFT4j3evHyyc7R_lOZooG6_iBAX7WU";


        // Initialize a new RequestQueue instance
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

        // Initialize a new JsonArrayRequest instance
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, metadataURL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                // Do something with response
                // Process the JSON
                progressBarBackgroundImage.setVisibility(View.GONE);
                try {
                    // Get the current student (json object) data
                    status = response.getString("status");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (status.equalsIgnoreCase("OK")) {
                    String imageURL = "https://maps.googleapis.com/maps/api/streetview?size=800x800&location=" + latOng + "," + longOng + "&fov=120&heading=151.7&pitch=10&key=AIzaSyC5MEFT4j3evHyyc7R_lOZooG6_iBAX7WU";
                    Glide.with(getApplicationContext())
                            .load(imageURL)
                            .into(src);
                } else {
                    src.setImageResource(0);
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Do something when error occurred
                    }
                }
        );

        // Add JsonArrayRequest to the RequestQueue
        requestQueue.add(jsonObjectRequest);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }

    public void clickCall(View view) {

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            //Run-time request permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, MY_PERMISSION_REQUEST_CODE);
        } else {
            if (checkPlayServices()) {
                callToOng();
            }
        }

        callToOng();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (checkPlayServices())
                        callToOng();
                }
                break;
        }
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode,
                        this, PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Toast.makeText(getApplicationContext(), "This device is not supported", Toast.LENGTH_LONG).show();
            }
            return false;
        }
        return true;
    }

    public void callToOng() {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + telefoneOng));

        if (ActivityCompat.checkSelfPermission(ProfileOngActivity.this,
                android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    private void createFragments() {

        //Initializing the tablayout
        tabLayout = findViewById(R.id.tabLayout);

        //Initializing viewPager
        viewPager = findViewById(R.id.pager);

        //Adding the tabs using addTab() method
        tabLayout.addTab(tabLayout.newTab().setText("SOBRE"));
        tabLayout.addTab(tabLayout.newTab().setText("LOCALIZAÇÃO"));
        tabLayout.addTab(tabLayout.newTab().setText("NECESSIDADES"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        //Creating our pager adapter
        Pager adapter = new Pager(getSupportFragmentManager(), tabLayout.getTabCount());

        //Adding adapter to pager
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        //Adding onTabSelectedListener to swipe views
        tabLayout.addOnTabSelectedListener(this);

        progressBarViewPager.setVisibility(View.GONE);

    }

    private class Pager extends FragmentStatePagerAdapter {
        //integer to count number of tabs
        int tabCount;

        //Constructor to the class
        private Pager(FragmentManager fm, int tabCount) {
            super(fm);
            //Initializing tab count
            this.tabCount = tabCount;
        }

        //Overriding method getItem
        @Override
        public Fragment getItem(int position) {
            //Returning the current tabs
            switch (position) {
                case 0:
                    AboutFragment aboutFragment = new AboutFragment();
                    aboutFragment.setArguments(bundle);
                    return aboutFragment;
                case 1:
                    LocalFragment localFragment = new LocalFragment();
                    localFragment.setArguments(bundle1);
                    return localFragment;
                case 2:
                    NeedsFragment needsFragment = new NeedsFragment();
                    needsFragment.setArguments(bundle2);
                    return needsFragment;
                default:
                    return null;
            }
        }

        //Overriden method getCount to get the number of tabs
        @Override
        public int getCount() {
            return tabCount;
        }

    }
}
