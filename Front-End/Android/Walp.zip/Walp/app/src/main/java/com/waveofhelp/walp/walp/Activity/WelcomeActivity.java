package com.waveofhelp.walp.walp.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.multidex.MultiDex;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.waveofhelp.walp.walp.Activity.SignUpOngActivity.SignupOngActivity;
import com.waveofhelp.walp.walp.Adapters.PagerAdapter;
import com.waveofhelp.walp.walp.Constants;
import com.waveofhelp.walp.walp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import static com.waveofhelp.walp.walp.Constants.URL_REGISTER;


/**
 * Created by Pedro on 18/03/2017.
 */

public class WelcomeActivity extends FragmentActivity {
    ViewPager viewpager;

    private LoginButton loginButton;
    private CallbackManager callbackManager;
    private String foto, nome, email, id, token;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        viewpager = findViewById(R.id.pager);
        PagerAdapter padapter = new PagerAdapter(getSupportFragmentManager());
        viewpager.setAdapter(padapter);

        TabLayout tabLayout =  findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(viewpager, true);

        callbackManager = CallbackManager.Factory.create();

        loginButton =  findViewById(R.id.login_button_facebook);

        loginButton.setReadPermissions(Arrays.asList("email"));

        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(final LoginResult loginResult) {
                GraphRequest request = GraphRequest.newMeRequest(
                        loginResult.getAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(
                                    JSONObject object,
                                    GraphResponse response) {
                                Log.v("TAG", "JSON: " + object);
                                try {
                                    id = object.getString("id");
                                    foto = "https://graph.facebook.com/"+id+"/picture?height=120&width=120";
                                    nome = object.getString("name");
                                    email = object.getString("email");
                                    token = loginResult.getAccessToken().getToken();

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                final ProgressDialog progressDialog = new ProgressDialog(WelcomeActivity.this,
                        R.style.Theme_AppCompat_DayNight_Dialog_MinWidth);
                progressDialog.setMessage("Salvando...");
                progressDialog.setIndeterminate(true);
                progressDialog.show();

                StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGISTER,
                        new Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {
                                //If we are getting success from server
                                if (response.equalsIgnoreCase(Constants.Success)) {
                                    //Creating a shared preference
                                    SharedPreferences sharedPreferences = WelcomeActivity.this.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                                    //Creating editor to store values to shared preferences
                                    SharedPreferences.Editor editor = sharedPreferences.edit();

                                    //Adding values to editor
                                    editor.putBoolean(Constants.LOGGEDIN_SHARED_PREF, true);
                                    editor.putString(Constants.EMAIL_SHARED_PREF, email);
                                    editor.putString(Constants.USER_TYPE_SHARED_PREF, "1");

                                    //Saving values to editor
                                    editor.commit();
                                    progressDialog.dismiss();
                                    goMainScreen();
                                } else {
                                    Toast.makeText(WelcomeActivity.this, response, Toast.LENGTH_LONG).show();
                                    progressDialog.dismiss();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(WelcomeActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                                progressDialog.dismiss();
                            }
                        }){
                    @Override
                    protected Map<String,String> getParams() throws AuthFailureError {

                        Map<String,String> params = new HashMap<String, String>();

                        params.put("nome_user",nome);
                        params.put("email_user",email);
                        params.put("img_user",foto);
                        params.put("tkfacebook_user", token);

                        params.put(Constants.EMAIL_SHARED_PREF, email);
                        Log.i("ENVIADOO","DEU CERTO");
                        return params;
                    }

                };

                stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            }

            @Override
            public void onCancel() {
                Toast.makeText(getApplicationContext(), "Atividade cancelada", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException exception) {
                Toast.makeText(getApplicationContext(), "Ocorreu um erro", Toast.LENGTH_SHORT).show();
            }
        });

        String termsAndConditions = "Termos e Condições";
        String privacyPolicy = "Política de Privacidade";
        TextView legalDescription = findViewById(R.id.legal_description);

        legalDescription.setText(
                String.format(
                        "Ao continuar, você está indicando que " +
                                "leu a Política de Privacidade e aceita " +
                                " aos Termos e Condições.",
                        termsAndConditions,
                        privacyPolicy)
        );
        legalDescription.setMovementMethod(LinkMovementMethod.getInstance());

        Pattern termsAndConditionsMatcher = Pattern.compile(termsAndConditions);
        Linkify.addLinks(legalDescription, termsAndConditionsMatcher, "http://walpweb.com.br/");

        Pattern privacyPolicyMatcher = Pattern.compile(privacyPolicy);
        Linkify.addLinks(legalDescription, privacyPolicyMatcher, "http://walpweb.com.br/");

    }

    private void goMainScreen() {
        Intent intent = new Intent(this,MainUserActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        callbackManager.onActivityResult(requestCode,resultCode,data);
    }

    public void clickLoginButton(View view) {
        Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    public void clickSkipButton(View view) {
        Intent intent = new Intent(WelcomeActivity.this, MainUserActivity.class);
        startActivity(intent);
    }

    public void clickSignupButton(View view) {
        Intent intent = new Intent(WelcomeActivity.this, SignUpUserActivity.class);
        startActivity(intent);
    }

    public void clickOngButton(View view) {
        Intent intent = new Intent(WelcomeActivity.this, SignupOngActivity.class);
        startActivity(intent);
    }

}