package com.waveofhelp.walp.walp;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.waveofhelp.walp.walp.Activity.MainUserActivity;
import com.waveofhelp.walp.walp.NetworkControllers.NetworkController;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.content.ContentValues.TAG;

/**
 * Created by beta17 on 22/05/18.
 */

public class GPS_Service extends JobService implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    public LocationListener listener;
    private LocationManager locationManager;
    private GoogleApiClient googleApiClient;
    DatabaseReference ref;
    private JobParameters mJobParameters;
    GeoFire geoFire;
    private double lat_user, long_user;
    private RequestQueue queue;

    public int counter = 0;

    public GPS_Service(Context applicationContext) {
        super();
        Log.i("HERE", "here I am!");
    }

    public GPS_Service() {
    }

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        Log.i(TAG, "JobSchedulerService.onStartJob()");
        mJobParameters = jobParameters;
        callConection();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        Log.i(TAG, "JobSchedulerService.onStopJob()");
        return true;
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onCreate() {
        queue = Volley.newRequestQueue(getBaseContext());
        geoFire();
        updateLocation();
    }

    private JsonArrayRequest getDataFromServer() {

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getBaseContext()).getRequestQueue();

        //Volley's inbuilt class to make Json array request
        String url = Constants.URL_LATLONG_ONG;
        return new JsonArrayRequest(url + "?lat_user=" + lat_user + "&long_user=" + long_user, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {

                //Calling method parseData to parse the json response
                try {
                    parseData(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage());
            }

        });
    }

    //This method will get data from the web api
    private void getData() {
        //Adding the method to the queue by calling the method getDataFromServer
        queue.add(getDataFromServer());
    }

    //This method will parse json data
    private void parseData(JSONArray array) throws JSONException {
        if (!array.toString().equals(" ")) {
            LatLng[] ongLatLng = new LatLng[array.length()];
            String necessidade = "";
            for (int i = 0; i < array.length(); i++) {

                JSONObject json;
                try {
                    //Getting json
                    json = array.getJSONObject(i);

                    //Adding data to the ONG object
                    ongLatLng[i] = new LatLng(Double.parseDouble(json.getString("LAT_ONG")), Double.parseDouble(json.getString("LONG_ONG")));
                    necessidade = (json.getString("NECESSIDADE"));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            geoQuery(ongLatLng,necessidade);
        }
    }

    private void geoQuery(LatLng[] ongLatLng, final String necessidade) {
        //Add GeoQuery here
        //0.5f = 500m
        GeoQuery[] geoQueries = new GeoQuery[ongLatLng.length];
        for (int i = 1; i <= ongLatLng.length; i++) {
            if (i < ongLatLng.length && ongLatLng[i]!=null) {
                geoQueries[i] = geoFire.queryAtLocation(new GeoLocation(ongLatLng[i].latitude, ongLatLng[i].longitude), 0.5f);
                geoQueries[i].addGeoQueryEventListener(new GeoQueryEventListener() {
                    @Override
                    public void onKeyEntered(String key, GeoLocation location) {
                        sendNotification(necessidade);
                    }

                    @Override
                    public void onKeyExited(String key) {

                    }

                    @Override
                    public void onKeyMoved(String key, GeoLocation location) {

                    }

                    @Override
                    public void onGeoQueryReady() {

                    }

                    @Override
                    public void onGeoQueryError(DatabaseError error) {

                    }
                });
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //if (locationManager != null) {
        //noinspection MissingPermission
        //    locationManager.removeUpdates(listener);
        //}
        //Log.i(TAG, "Service onDestroy");
        //Intent i = new Intent(getApplicationContext(), GPS_Service.class);
        //stopService(i);
        Log.i("EXIT", "ondestroy!");
        Intent broadcastIntent = new Intent("uk.ac.shef.oak.ActivityRecognition.RestartSensor");
        sendBroadcast(broadcastIntent);
    }

    private synchronized void callConection() {
        googleApiClient = new GoogleApiClient.Builder(this)
                .addOnConnectionFailedListener(this)
                .addConnectionCallbacks(this)
                .addApi(LocationServices.API)
                .build();
        googleApiClient.connect();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.d(TAG, "Google Api Client Connected");
        Log.i(TAG, "JobSchedulerService.onConnected()");
    }

    public void geoFire() {
        ref = FirebaseDatabase.getInstance().getReference("MyLocation");
        geoFire = new GeoFire(ref);

        updateLocation();
    }

    public void updateLocation() {

        listener = new LocationListener() {
            @Override
            public void onLocationChanged(final Location location) {
                Intent i = new Intent("location_update");
                i.putExtra("coordinates", location.getLongitude() + " " + location.getLatitude());

                lat_user = location.getLatitude();
                long_user = location.getLongitude();
                getData();

                geoFire.setLocation("You", new GeoLocation(location.getLatitude(), location.getLongitude()), new
                        GeoFire.CompletionListener() {
                            @Override
                            public void onComplete(String key, DatabaseError error) {
                                //getData();
                            }
                        });

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        };

        locationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);


        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 0, listener);
        getData();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d(TAG, "Google Connection Suspended");
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.e(TAG, "Connection Failed:" + connectionResult.getErrorMessage());
    }

    public void sendNotification(String necessidade) {


        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(getApplicationContext(), NOTIFICATION_CHANNEL_ID);

        Intent intent = new Intent(getApplicationContext(), MainUserActivity.class);
        // Create the PendingIntent
        PendingIntent notifyOngPendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent notifyListPendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        notificationBuilder.setAutoCancel(false)
                .setSmallIcon(R.drawable.ic_push).setColor(4096429)
                .setPriority(Notification.DEFAULT_ALL)
                .addAction(R.drawable.ic_arrow_forward_black_24dp, "AJUDAR", notifyOngPendingIntent)
                .addAction(R.drawable.ic_arrow_forward_black_24dp, "VER MAIS ONGS", notifyListPendingIntent)
                .setContentTitle("Você está próximo de uma ONG")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Ela está precisando de "+necessidade))
                .setContentText("Clique para ver mais")
                .setSound(notificationSound);

        notificationBuilder.setContentIntent(notifyOngPendingIntent);
        notificationManager.notify(/*notification id*/1, notificationBuilder.build());
    }
}
